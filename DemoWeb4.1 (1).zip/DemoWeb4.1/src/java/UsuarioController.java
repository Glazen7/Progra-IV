
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "UsuarioController")
@SessionScoped

public class UsuarioController implements Serializable {

    private UsuarioTO selectedUsuario = new UsuarioTO();
    private UsuarioTO newUsuario = new UsuarioTO();
    private ServicioUsuario su = new ServicioUsuario();
    private List<UsuarioTO> listaUsuariosIndividuales = new ArrayList<>();
    private List<UsuarioTO> listaUsuarios = new ArrayList<>();
    private UsuarioTO usuarioVacacion = new UsuarioTO();
    private ServicioVacaciones sv = new ServicioVacaciones();
    private Fechas selectedFechas = new Fechas();
    private ServicioPermisos sp = new ServicioPermisos();
    private String motivo;

    public UsuarioController() {
    }

    public List<UsuarioTO> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(List<UsuarioTO> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
    
    public UsuarioTO getUsuarioVacacion() {
        return usuarioVacacion;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public void setUsuarioVacacion(UsuarioTO usuarioVacacion) {
        this.usuarioVacacion = usuarioVacacion;
    }

    public UsuarioTO getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(UsuarioTO selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public UsuarioTO getNewUsuario() {
        return newUsuario;
    }

    public void setNewUsuario(UsuarioTO newUsuario) {
        this.newUsuario = newUsuario;
    }

    public ServicioUsuario getSu() {
        return su;
    }

    public void setSu(ServicioUsuario su) {
        this.su = su;
    }

    public List<UsuarioTO> getListaUsuariosIndividuales() {
        return listaUsuariosIndividuales;
    }

    public void setListaUsuariosIndividuales(List<UsuarioTO> listaUsuariosIndividuales) {
        this.listaUsuariosIndividuales = listaUsuariosIndividuales;
    }

    public Fechas getSelectedFechas() {
        return selectedFechas;
    }

    public void setSelectedFechas(Fechas selectedFechas) {
        this.selectedFechas = selectedFechas;
    }
    
    public void iniciar(String correo) {
        this.listaUsuariosIndividuales = su.listarIndividual(correo);
        PrimeFaces.current().ajax().update(":form");
    }
    
    @PostConstruct
    public void inicializar(){
        this.listaUsuarios = su.listar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void saveUser(UsuarioTO u) {
        su.actualizarPersonal(u);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void actualizarUser(UsuarioTO u) {
        su.actualizar(u);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void eliminarUser(UsuarioTO u,String correo) {
        su.eliminar(u);
        iniciar(correo);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void insertarUser(UsuarioTO u) {
        u.setActivo(1);
        su.insertar(u);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void insertVacacion(String correo) {
        UsuarioTO u = this.listaUsuariosIndividuales.get(0);
        sv.sacarDiasVacacionesDispon(u);
        sv.sacarDiasVacacionesTomadas(u, selectedFechas.getFechaInicio(), selectedFechas.getFechaFinal());
        iniciar(correo);
    }

    public void insertPermiso(String correo) {
        UsuarioTO u = this.listaUsuariosIndividuales.get(0);
        sp.sacarDiasPermisosDispon(u);
        sp.sacarDiasPermisosTomadas(u, selectedFechas.getFechaInicio(), selectedFechas.getFechaFinal(),motivo);
        iniciar(correo);
    }
}
