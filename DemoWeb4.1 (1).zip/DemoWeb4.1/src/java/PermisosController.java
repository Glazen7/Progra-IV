
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "PermisosController")
@SessionScoped

public class PermisosController implements Serializable {

    private List<Permisos> listaPermisos;
    private List<Permisos> listaPermisosPersonal;
    private List<Permisos> listaPermisosAprobados;
    private List<Permisos> listaPermisosRechazados;
    private List<Permisos> listaPermisosPendientes;
    private List<Permisos> listaPermisosRechazadosPersonal;
    private List<Permisos> listaPermisosAprobadosPersonal;
    private List<Permisos> listaPermisosPendientesPersonal;
    private List<Permisos> listaPermisosPendientesManager;
    private List<Permisos> listaPermisosAprobadosManager;
    private List<Permisos> listaPermisosRechazadosManager;
    private List<Permisos> listaPermisosRechazadosUsuario;
    private List<Permisos> listaPermisosAprobadosUsuario;
    private List<Permisos> listaPermisosPendientesUsuario;
    private List<Permisos> listaPermisosPendientesAdministrador;
    private List<Permisos> listaPermisosAprobadosAdministrador;
    private List<Permisos> listaPermisosRechazadosAdministrador;
    private EnviarCorreo ec = new EnviarCorreo();
    private ServicioUsuario su = new ServicioUsuario();
    private Permisos selectedPermiso = new Permisos();
    private Permisos newPermiso = new Permisos();
    ServicioPermisos sp = new ServicioPermisos();
    
    
    public PermisosController() {
    }

    public List<Permisos> getListaPermisosPendientesAdministrador() {
        return listaPermisosPendientesAdministrador;
    }

    public void setListaPermisosPendientesAdministrador(List<Permisos> listaPermisosPendientesAdministrador) {
        this.listaPermisosPendientesAdministrador = listaPermisosPendientesAdministrador;
    }

    public List<Permisos> getListaPermisosAprobadosAdministrador() {
        return listaPermisosAprobadosAdministrador;
    }

    public void setListaPermisosAprobadosAdministrador(List<Permisos> listaPermisosAprobadosAdministrador) {
        this.listaPermisosAprobadosAdministrador = listaPermisosAprobadosAdministrador;
    }

    public List<Permisos> getListaPermisosRechazadosAdministrador() {
        return listaPermisosRechazadosAdministrador;
    }

    public void setListaPermisosRechazadosAdministrador(List<Permisos> listaPermisosRechazadosAdministrador) {
        this.listaPermisosRechazadosAdministrador = listaPermisosRechazadosAdministrador;
    }

    public List<Permisos> getListaPermisosPersonal() {
        return listaPermisosPersonal;
    }

    public void setListaPermisosPersonal(List<Permisos> listaPermisosPersonal) {
        this.listaPermisosPersonal = listaPermisosPersonal;
    }

    public EnviarCorreo getEc() {
        return ec;
    }

    public void setEc(EnviarCorreo ec) {
        this.ec = ec;
    }

    public ServicioUsuario getSu() {
        return su;
    }

    public void setSu(ServicioUsuario su) {
        this.su = su;
    }
    
    
    public List<Permisos> getListaPermisos() {
        return listaPermisos;
    }

    public void setListaPermisos(List<Permisos> listaPermisos) {
        this.listaPermisos = listaPermisos;
    }

    public Permisos getSelectedPermiso() {
        return selectedPermiso;
    }

    public void setSelectedPermiso(Permisos selectedPermiso) {
        this.selectedPermiso = selectedPermiso;
    }

    public Permisos getNewPermiso() {
        return newPermiso;
    }

    public void setNewPermiso(Permisos newPermiso) {
        this.newPermiso = newPermiso;
    }

    public List<Permisos> getListaPermisosAprobados() {
        return listaPermisosAprobados;
    }

    public void setListaPermisosAprobados(List<Permisos> listaPermisosAprobados) {
        this.listaPermisosAprobados = listaPermisosAprobados;
    }

    public List<Permisos> getListaPermisosRechazados() {
        return listaPermisosRechazados;
    }

    public void setListaPermisosRechazados(List<Permisos> listaPermisosRechazados) {
        this.listaPermisosRechazados = listaPermisosRechazados;
    }

    public List<Permisos> getListaPermisosPendientes() {
        return listaPermisosPendientes;
    }

    public void setListaPermisosPendientes(List<Permisos> listaPermisosPendientes) {
        this.listaPermisosPendientes = listaPermisosPendientes;
    }

    public List<Permisos> getListaPermisosRechazadosPersonal() {
        return listaPermisosRechazadosPersonal;
    }

    public void setListaPermisosRechazadosPersonal(List<Permisos> listaPermisosRechazadosPersonal) {
        this.listaPermisosRechazadosPersonal = listaPermisosRechazadosPersonal;
    }

    public List<Permisos> getListaPermisosAprobadosPersonal() {
        return listaPermisosAprobadosPersonal;
    }

    public void setListaPermisosAprobadosPersonal(List<Permisos> listaPermisosAprobadosPersonal) {
        this.listaPermisosAprobadosPersonal = listaPermisosAprobadosPersonal;
    }

    public List<Permisos> getListaPermisosPendientesPersonal() {
        return listaPermisosPendientesPersonal;
    }

    public void setListaPermisosPendientesPersonal(List<Permisos> listaPermisosPendientesPersonal) {
        this.listaPermisosPendientesPersonal = listaPermisosPendientesPersonal;
    }

    public List<Permisos> getListaPermisosPendientesManager() {
        return listaPermisosPendientesManager;
    }

    public void setListaPermisosPendientesManager(List<Permisos> listaPermisosPendientesManager) {
        this.listaPermisosPendientesManager = listaPermisosPendientesManager;
    }

    public List<Permisos> getListaPermisosAprobadosManager() {
        return listaPermisosAprobadosManager;
    }

    public void setListaPermisosAprobadosManager(List<Permisos> listaPermisosAprobadosManager) {
        this.listaPermisosAprobadosManager = listaPermisosAprobadosManager;
    }

    public List<Permisos> getListaPermisosRechazadosManager() {
        return listaPermisosRechazadosManager;
    }

    public void setListaPermisosRechazadosManager(List<Permisos> listaPermisosRechazadosManager) {
        this.listaPermisosRechazadosManager = listaPermisosRechazadosManager;
    }

    public List<Permisos> getListaPermisosRechazadosUsuario() {
        return listaPermisosRechazadosUsuario;
    }

    public void setListaPermisosRechazadosUsuario(List<Permisos> listaPermisosRechazadosUsuario) {
        this.listaPermisosRechazadosUsuario = listaPermisosRechazadosUsuario;
    }

    public List<Permisos> getListaPermisosAprobadosUsuario() {
        return listaPermisosAprobadosUsuario;
    }

    public void setListaPermisosAprobadosUsuario(List<Permisos> listaPermisosAprobadosUsuario) {
        this.listaPermisosAprobadosUsuario = listaPermisosAprobadosUsuario;
    }

    public List<Permisos> getListaPermisosPendientesUsuario() {
        return listaPermisosPendientesUsuario;
    }

    public void setListaPermisosPendientesUsuario(List<Permisos> listaPermisosPendientesUsuario) {
        this.listaPermisosPendientesUsuario = listaPermisosPendientesUsuario;
    }
    

    public void actualizarPermiso(Permisos p) {
        sp.actualizar(p);
    }
    public void aprobarPermiso(Permisos p) {
        int estado = 1;
        sp.actualizarSolicitud(p, estado);
        String mail= su.buscarCorreo(p.getNombreSolicitante());
        ec.createEmailPermisosAceptados(mail, p.getFechaSolicitada(),p.getRazonPermiso());
        ec.sendEmail();
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void rechazarPermiso(Permisos p) {
        int estado = 2;
        sp.actualizarSolicitud(p, estado);
        String mail= su.buscarCorreo(p.getNombreSolicitante());
        ec.createEmailPermisosRechazados(mail, p.getFechaSolicitada(),p.getRazonPermiso());
        ec.sendEmail();
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }
    public void iniciar(String filtro) {
        this.listaPermisosRechazadosPersonal =sp.listarRechazadasPersonal(filtro);
        this.listaPermisosAprobadosPersonal=sp.listarAprobadasPersonal(filtro);
        this.listaPermisosPendientesPersonal=sp.listarPendientesPersonal(filtro);
        PrimeFaces.current().ajax().update(":form");
    }

    @PostConstruct
    public void inicializar() {
        this.listaPermisos=sp.listar();
        this.listaPermisosAprobados = sp.listarAprobadas();
        this.listaPermisosPendientes = sp.listarPendientes();
        this.listaPermisosRechazados = sp.listarRechazadas();
        this.listaPermisosPendientesManager = sp.listarPendientesManager();
        this.listaPermisosAprobadosManager = sp.listarAprobadasManager();
        this.listaPermisosRechazadosManager = sp.listarRechazadasManager();
        this.listaPermisosAprobadosUsuario = sp.listarAprobadasUsuario();
        this.listaPermisosPendientesUsuario = sp.listarPendientesUsuario();
        this.listaPermisosRechazadosUsuario = sp.listarRechazadasUsuario();
        this.listaPermisosAprobadosAdministrador=sp.listarAprobadasAdminitrador();
        this.listaPermisosPendientesAdministrador=sp.listarPendientesAdministrador();
        this.listaPermisosRechazadosAdministrador=sp.listarRechazadasAdministrador();
    }
}
