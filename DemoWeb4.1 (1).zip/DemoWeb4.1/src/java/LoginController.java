
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "LoginController")
@SessionScoped

public class LoginController implements Serializable {

    private String Correo, Clave, Opcion;
    private List<UsuarioTO> listaUsuarios = new ArrayList<>();
    private List<UsuarioTO> listaUsuariosIndividuales = new ArrayList<>();
    private boolean esNuevo;
    private UsuarioTO selectedUsuario = new UsuarioTO();
    private UsuarioTO usuario = new UsuarioTO();
    private Administrador admin = new Administrador();
    private Manager manager = new Manager();
    private Autentificar auth = new Autentificar();
    private ServicioUsuario su = new ServicioUsuario();

    public LoginController(String Correo, String Clave, String Opcion, boolean esNuevo) {
        this.Correo = Correo;
        this.Clave = Clave;
        this.Opcion = Opcion;
        this.esNuevo = esNuevo;
    }

    public LoginController() {
    }

    public List<UsuarioTO> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(List<UsuarioTO> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public void openNew() {
        this.esNuevo = true;
        this.selectedUsuario = new UsuarioTO();
    }

    public boolean isEsNuevo() {
        return esNuevo;
    }

    public void setEsNuevo(boolean esNuevo) {
        this.esNuevo = esNuevo;
    }

    public UsuarioTO getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(UsuarioTO selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        this.Correo = correo;
    }

    public String getClave() {
        return Clave;
    }

    public void setClave(String clave) {
        this.Clave = clave;
    }

    public String getOpcion() {
        return Opcion;
    }

    public void setOpcion(String Opcion) {
        this.Opcion = Opcion;
    }

    public UsuarioTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioTO usuario) {
        this.usuario = usuario;
    }

    public Administrador getAdmin() {
        return admin;
    }

    public void setAdmin(Administrador admin) {
        this.admin = admin;
    }

    public List<UsuarioTO> getListaUsuariosIndividuales() {
        return listaUsuariosIndividuales;
    }

    public void setListaUsuariosIndividuales(List<UsuarioTO> listaUsuariosIndividuales) {
        this.listaUsuariosIndividuales = listaUsuariosIndividuales;
    }

    public void inicializar() {
        this.listaUsuarios = su.listar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void ingresar() {
        boolean continuar = true;
        if (this.getCorreo() == null || this.getCorreo().equals("")) {
            //ERROR
            FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Campos inválidos", "El usuario no es correcto"));
            continuar = false;
        }
        if (this.getClave() == null || this.getClave().equals("")) {
            //ERROR
            FacesContext.getCurrentInstance().addMessage("sticky-key", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Campos inválidos", "La contraseña no es correcta"));
            continuar = false;
        }
        if (continuar) {

            this.listaUsuarios = su.listar();
            this.listaUsuariosIndividuales = su.listarIndividual(Correo);
            asignarValores();

            if (auth.autentificarLogin(usuario, admin, manager) == 1) {
                this.redireccionar("/faces/usuarios.xhtml");
            }
            if (auth.autentificarLogin(usuario, admin, manager) == 2) {
                this.redireccionar("/faces/bienvenida.xhtml");
            }
            if (auth.autentificarLogin(usuario, admin, manager) == 3) {
                this.redireccionar("/faces/managers.xhtml");
            }
        }
    }

    public void asignarValores() {
        this.usuario.setNombre(Correo);
        this.usuario.setContrasena(Clave);
        this.admin.setNombre(Correo);
        this.admin.setContrasena(Clave);
        this.manager.setNombre(Correo);
        this.manager.setContrasena(Clave);
    }

    public void redireccionar(String ruta) {
        HttpServletRequest request;
        try {
            request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
            FacesContext.getCurrentInstance().getExternalContext().redirect(request.getContextPath() + ruta);
        } catch (Exception e) {
        }
    }

    public void salir() {
        this.redireccionar("/faces/index.xhtml");
    }
}
