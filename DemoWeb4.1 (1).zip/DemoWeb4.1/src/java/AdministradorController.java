
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "AdministradorController")
@SessionScoped

public class AdministradorController implements Serializable {

    private List<Administrador> listaAdmin = new ArrayList<>();
    private List<Administrador> listaAdminPersonal = new ArrayList<>();
    private ServicioAdministrador sa = new ServicioAdministrador();
    private Manager selectedManager = new Manager();
    private UsuarioTO selectedUsuario = new UsuarioTO();
    private ServicioUsuario su = new ServicioUsuario();
    private Administrador selectedAdministrador = new Administrador();
    private Administrador newAdministrador = new Administrador();
    private List<Vacaciones> listaVacacionesRechazadasAdministrador = new ArrayList<>();
    private List<Vacaciones> listaVacacionesAprobadasAdministrador = new ArrayList<>();
    private List<Vacaciones> listaVacacionesPendientesAdministrador = new ArrayList<>();
    private List<Permisos> listaPermisosRechazadasAdministrador = new ArrayList<>();
    private List<Permisos> listaPermisosAprobadasAdministrador = new ArrayList<>();
    private List<Permisos> listaPermisosPendientesAdministrador = new ArrayList<>();
    private String fechaInicial;
    private String fechaFinal;
    private ServicioVacaciones sv = new ServicioVacaciones();
    private ServicioPermisos sp = new ServicioPermisos();
    private String motivo;

    public AdministradorController() {
    }

    public List<Permisos> getListaPermisosRechazadasAdministrador() {
        return listaPermisosRechazadasAdministrador;
    }

    public void setListaPermisosRechazadasAdministrador(List<Permisos> listaPermisosRechazadasAdministrador) {
        this.listaPermisosRechazadasAdministrador = listaPermisosRechazadasAdministrador;
    }

    public List<Permisos> getListaPermisosAprobadasAdministrador() {
        return listaPermisosAprobadasAdministrador;
    }

    public void setListaPermisosAprobadasAdministrador(List<Permisos> listaPermisosAprobadasAdministrador) {
        this.listaPermisosAprobadasAdministrador = listaPermisosAprobadasAdministrador;
    }

    public List<Permisos> getListaPermisosPendientesAdministrador() {
        return listaPermisosPendientesAdministrador;
    }

    public void setListaPermisosPendientesAdministrador(List<Permisos> listaPermisosPendientesAdministrador) {
        this.listaPermisosPendientesAdministrador = listaPermisosPendientesAdministrador;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getFechaInicial() {
        return fechaInicial;
    }

    public void setFechaInicial(String fechaInicial) {
        this.fechaInicial = fechaInicial;
    }

    public String getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(String fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public Administrador getNewAdministrador() {
        return newAdministrador;
    }

    public void setNewAdministrador(Administrador newAdministrador) {
        this.newAdministrador = newAdministrador;
    }

    public Administrador getSelectedAdministrador() {
        return selectedAdministrador;
    }

    public void setSelectedAdministrador(Administrador selectedAdministrador) {
        this.selectedAdministrador = selectedAdministrador;
    }

    public List<Administrador> getListaAdminPersonal() {
        return listaAdminPersonal;
    }

    public void setListaAdminPersonal(List<Administrador> listaAdminPersonal) {
        this.listaAdminPersonal = listaAdminPersonal;
    }

    public List<Administrador> getListaAdmin() {
        return listaAdmin;
    }

    public void setListaAdmin(List<Administrador> listaAdmin) {
        this.listaAdmin = listaAdmin;
    }

    public Manager getSelectedManager() {
        return selectedManager;
    }

    public void setSelectedManager(Manager selectedManager) {
        this.selectedManager = selectedManager;
    }

    public UsuarioTO getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(UsuarioTO selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public void guardarUsuario(UsuarioTO u) {
        su.insertar(u);
    }

    public void iniciar(String identifier) {
        this.listaAdminPersonal = sa.listarAdministradorPropio(identifier);
        PrimeFaces.current().ajax().update(":form");
    }

    public void iniciarListaAdministradores() {
        Administrador a = this.listaAdminPersonal.get(0);
        this.listaAdmin = sa.listar();
        for (int i = listaAdmin.size() - 1; i >= 0; i--) {
            Administrador ad = listaAdmin.get(i);
            if (ad.getNombre().equals(a.getNombre())) {
                listaAdmin.remove(i);
            }
        }
        PrimeFaces.current().ajax().update(":form");
    }

    public void actualizarAdministrador(Administrador a) {
        sa.actualizar(a);
    }

    public void insertarAdministrador(Administrador a) {
        a.setActivo(1);
        sa.insertar(a);
    }

    public void eliminarAdministrador(Administrador a) {
        sa.eliminar(a);
        iniciarListaAdministradores();
    }

    public List<Vacaciones> getListaVacacionesRechazadasAdministrador() {
        return listaVacacionesRechazadasAdministrador;
    }

    public void setListaVacacionesRechazadasAdministrador(List<Vacaciones> listaVacacionesRechazadasAdministrador) {
        this.listaVacacionesRechazadasAdministrador = listaVacacionesRechazadasAdministrador;
    }

    public List<Vacaciones> getListaVacacionesAprobadasAdministrador() {
        return listaVacacionesAprobadasAdministrador;
    }

    public void setListaVacacionesAprobadasAdministrador(List<Vacaciones> listaVacacionesArobadasAdministrador) {
        this.listaVacacionesAprobadasAdministrador = listaVacacionesArobadasAdministrador;
    }

    public List<Vacaciones> getListaVacacionesPendientesAdministrador() {
        return listaVacacionesPendientesAdministrador;
    }

    public void setListaVacacionesPendientesAdministrador(List<Vacaciones> listaVacacionesPendientesAdministrador) {
        this.listaVacacionesPendientesAdministrador = listaVacacionesPendientesAdministrador;
    }

    public void insertVacacion() {
        Administrador a = this.listaAdminPersonal.get(0);
        sv.sacarVacacionesAdministradores(a, fechaInicial, fechaFinal);
        iniciarListas();
    }

    public void insertPermiso() {
        Administrador a = this.listaAdminPersonal.get(0);
        sp.sacarPermisosAdministradores(a, fechaInicial, fechaFinal, motivo);
        iniciarListas();
    }
    //Inicializar
    public void iniciarListasPermisos() {
        Administrador a = this.listaAdminPersonal.get(0);
        listaPermisosRechazadasAdministrador = sp.listarRechazadasAdministrador();
        listaPermisosAprobadasAdministrador = sp.listarAprobadasAdminitrador();
        listaPermisosPendientesAdministrador = sp.listarPendientesAdministrador();
        
        for (int i = listaPermisosAprobadasAdministrador.size() - 1; i >= 0; i--) {
            Permisos p = listaPermisosAprobadasAdministrador.get(i);

            if (p.getNombreSolicitante().equals(a.getNombre())) {
                listaPermisosAprobadasAdministrador.remove(i);
            }
        }
        for (int i = listaPermisosRechazadasAdministrador.size() - 1; i >= 0; i--) {
            Permisos p = listaPermisosRechazadasAdministrador.get(i);

            if (p.getNombreSolicitante().equals(a.getNombre())) {
                listaPermisosRechazadasAdministrador.remove(i);
            }
        }
        for (int i = listaPermisosPendientesAdministrador.size() - 1; i >= 0; i--) {
            Permisos p = listaPermisosPendientesAdministrador.get(i);

            if (p.getNombreSolicitante().equals(a.getNombre())) {
                listaPermisosPendientesAdministrador.remove(i);
            }
        }
        PrimeFaces.current().ajax().update(":form");
    }
    public void iniciarListas() {
        Administrador a = this.listaAdminPersonal.get(0);
        listaVacacionesRechazadasAdministrador = sv.listarRechazadasAdministrador();
        listaVacacionesAprobadasAdministrador = sv.listarAprobadasAdministrador();
        listaVacacionesPendientesAdministrador = sv.listarPendientesAdministrador();
        for (int i = listaVacacionesAprobadasAdministrador.size() - 1; i >= 0; i--) {
            Vacaciones v = listaVacacionesAprobadasAdministrador.get(i);

            if (v.getNombreSolicitante().equals(a.getNombre())) {
                listaVacacionesAprobadasAdministrador.remove(i);
            }
        }
        for (int i = listaVacacionesRechazadasAdministrador.size() - 1; i >= 0; i--) {
            Vacaciones v = listaVacacionesRechazadasAdministrador.get(i);

            if (v.getNombreSolicitante().equals(a.getNombre())) {
                listaVacacionesRechazadasAdministrador.remove(i);
            }
        }
        for (int i = listaVacacionesPendientesAdministrador.size() - 1; i >= 0; i--) {
            Vacaciones v = listaVacacionesPendientesAdministrador.get(i);

            if (v.getNombreSolicitante().equals(a.getNombre())) {
                listaVacacionesPendientesAdministrador.remove(i);
            }
        }
        PrimeFaces.current().ajax().update(":form");
    }
}
