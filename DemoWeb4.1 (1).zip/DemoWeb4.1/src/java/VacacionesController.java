
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "VacacionesController")
@SessionScoped

public class VacacionesController implements Serializable {

    Vacaciones va;
    private Vacaciones selectedVacacion = new Vacaciones();
    private Vacaciones pv;
    ServicioVacaciones sv = new ServicioVacaciones();
    private int idSolicitante, cantidadDiasSolicitados, cantidadDiasDisponibles;
    private String nombreSolicitante, fechaSolicitada;
    private List<Vacaciones> listaVacaciones;
    private List<Vacaciones> listaVacacionesRechazadas;
    private List<Vacaciones> listaVacacionesAprobadas;
    private List<Vacaciones> listaVacacionesPendientes;
    private List<Vacaciones> listaVacacionesRechazadasPersonal;
    private List<Vacaciones> listaVacacionesAprobadasPersonal;
    private List<Vacaciones> listaVacacionesPendientesPersonal;
    private List<Vacaciones> listaVacacionesPendienteManager;
    private List<Vacaciones> listaVacacionesAprobadasManager;
    private List<Vacaciones> listaVacacionesRechazadasManager;
    private List<Vacaciones> listaVacacionesRechazadasUsuario;
    private List<Vacaciones> listaVacacionesArobadasUsuario;
    private List<Vacaciones> listaVacacionesPendientesUsuario;
    private EnviarCorreo ec = new EnviarCorreo();
    private ServicioUsuario su = new ServicioUsuario();
    
    public VacacionesController() {
    }

    public EnviarCorreo getEc() {
        return ec;
    }

    public void setEc(EnviarCorreo ec) {
        this.ec = ec;
    }
    
    public List<Vacaciones> getListaVacacionesArobadasUsuario() {
        return listaVacacionesArobadasUsuario;
    }

    public void setListaVacacionesArobadasUsuario(List<Vacaciones> listaVacacionesArobadasUsuario) {
        this.listaVacacionesArobadasUsuario = listaVacacionesArobadasUsuario;
    }

    public List<Vacaciones> getListaVacacionesPendientesUsuario() {
        return listaVacacionesPendientesUsuario;
    }

    public void setListaVacacionesPendientesUsuario(List<Vacaciones> listaVacacionesPendientesUsuario) {
        this.listaVacacionesPendientesUsuario = listaVacacionesPendientesUsuario;
    }

    public List<Vacaciones> getListaVacacionesRechazadasUsuario() {
        return listaVacacionesRechazadasUsuario;
    }

    public void setListaVacacionesRechazadasUsuario(List<Vacaciones> listaVacacionesRechazadasUsuario) {
        this.listaVacacionesRechazadasUsuario = listaVacacionesRechazadasUsuario;
    }

    public List<Vacaciones> getListaVacacionesRechazadasManager() {
        return listaVacacionesRechazadasManager;
    }

    public void setListaVacacionesRechazadasManager(List<Vacaciones> listaVacacionesRechazadasManager) {
        this.listaVacacionesRechazadasManager = listaVacacionesRechazadasManager;
    }

    public List<Vacaciones> getListaVacacionesAprobadasManager() {
        return listaVacacionesAprobadasManager;
    }

    public void setListaVacacionesAprobadasManager(List<Vacaciones> listaVacacionesAprobadasManager) {
        this.listaVacacionesAprobadasManager = listaVacacionesAprobadasManager;
    }

    public List<Vacaciones> getListaVacacionesPendienteManager() {
        return listaVacacionesPendienteManager;
    }

    public void setListaVacacionesPendienteManager(List<Vacaciones> listaVacacionesPendienteManager) {
        this.listaVacacionesPendienteManager = listaVacacionesPendienteManager;
    }

    public List<Vacaciones> getListaVacacionesRechazadasPersonal() {
        return listaVacacionesRechazadasPersonal;
    }

    public void setListaVacacionesRechazadasPersonal(List<Vacaciones> listaVacacionesRechazadasPersonal) {
        this.listaVacacionesRechazadasPersonal = listaVacacionesRechazadasPersonal;
    }

    public List<Vacaciones> getListaVacacionesAprobadasPersonal() {
        return listaVacacionesAprobadasPersonal;
    }

    public void setListaVacacionesAprobadasPersonal(List<Vacaciones> listaVacacionesAprobadasPersonal) {
        this.listaVacacionesAprobadasPersonal = listaVacacionesAprobadasPersonal;
    }

    public List<Vacaciones> getListaVacacionesPendientesPersonal() {
        return listaVacacionesPendientesPersonal;
    }

    public void setListaVacacionesPendientesPersonal(List<Vacaciones> listaVacacionesPendientesPersonal) {
        this.listaVacacionesPendientesPersonal = listaVacacionesPendientesPersonal;
    }

    public List<Vacaciones> getListaVacacionesPendientes() {
        return listaVacacionesPendientes;
    }

    public void setListaVacacionesPendientes(List<Vacaciones> listaVacacionesPendientes) {
        this.listaVacacionesPendientes = listaVacacionesPendientes;
    }

    public int getIdSolicitante() {
        return idSolicitante;
    }

    public List<Vacaciones> getListaVacacionesAprobadas() {
        return listaVacacionesAprobadas;
    }

    public void setListaVacacionesAprobadas(List<Vacaciones> listaVacacionesAprobadas) {
        this.listaVacacionesAprobadas = listaVacacionesAprobadas;
    }

    public void setIdSolicitante(int idSolicitante) {
        this.idSolicitante = idSolicitante;
    }

    public int getCantidadDiasSolicitados() {
        return cantidadDiasSolicitados;
    }

    public void setCantidadDiasSolicitados(int cantidadDiasSolicitados) {
        this.cantidadDiasSolicitados = cantidadDiasSolicitados;
    }

    public int getCantidadDiasDisponibles() {
        return cantidadDiasDisponibles;
    }

    public void setCantidadDiasDisponibles(int cantidadDiasDisponibles) {
        this.cantidadDiasDisponibles = cantidadDiasDisponibles;
    }

    public String getNombreSolicitante() {
        return nombreSolicitante;
    }

    public void setNombreSolicitante(String nombreSolicitante) {
        this.nombreSolicitante = nombreSolicitante;
    }

    public String getFechaSolicitada() {
        return fechaSolicitada;
    }

    public void setFechaSolicitada(String fechaSolicitada) {
        this.fechaSolicitada = fechaSolicitada;
    }

    public Vacaciones getVa() {
        return va;
    }

    public void setVa(Vacaciones va) {
        this.va  = va;
    }

    public ServicioVacaciones getSv() {
        return sv;
    }

    public void setSv(ServicioVacaciones sv) {
        this.sv = sv;
    }

    public void aprobarVacacion(Vacaciones vac) {
        int estado = 1;
        sv.actualizarSolicitud(vac, estado);
        String mail= su.buscarCorreo(vac.getNombreSolicitante());
        ec.createEmailAceptados(mail, vac.getFechaSolicitada());
        ec.sendEmail();
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void rechazarVacacion(Vacaciones vac) {
        int estado = 2;
        sv.actualizarSolicitud(vac, estado);
        String mail= su.buscarCorreo(vac.getNombreSolicitante());
        ec.createEmailRechazados(mail, vac.getFechaSolicitada());
        ec.sendEmail();
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void actualizarVacacion(Vacaciones vac) {
        sv.actualizar(vac);
    }

    public Vacaciones getSelectedVacacion() {
        return selectedVacacion;
    }

    public void setSelectedVacacion(Vacaciones selectedVacacion) {
        this.selectedVacacion = selectedVacacion;
    }

    public List<Vacaciones> getListaVacaciones() {
        return listaVacaciones;
    }

    public void setListaVacaciones(List<Vacaciones> listaVacaciones) {
        this.listaVacaciones = listaVacaciones;
    }

    public List<Vacaciones> getListaVacacionesRechazadas() {
        return listaVacacionesRechazadas;
    }

    public void setListaVacacionesRechazadas(List<Vacaciones> listaVacacionesRechazadas) {
        this.listaVacacionesRechazadas = listaVacacionesRechazadas;
    }  
    
    public void iniciar(String filtro) {
        this.listaVacacionesRechazadasPersonal = sv.listarRechazadasPersonal(filtro);
        this.listaVacacionesAprobadasPersonal = sv.listarAprobadasPersonal(filtro);
        this.listaVacacionesPendientesPersonal = sv.listarPendientesPersonal(filtro);
        PrimeFaces.current().ajax().update(":form");
    }

    @PostConstruct
    public void inicializar() {
        this.listaVacaciones = sv.listar();
        this.listaVacacionesAprobadas = sv.listarAprobadas();
        this.listaVacacionesPendientes = sv.listarPendientes();
        this.listaVacacionesRechazadas = sv.listarRechazadas();
        this.listaVacacionesPendienteManager = sv.listarPendientesManager();
        this.listaVacacionesAprobadasManager = sv.listarAprobadasManager();
        this.listaVacacionesRechazadasManager = sv.listarRechazadasManager();
        this.listaVacacionesArobadasUsuario = sv.listarAprobadasUsuario();
        this.listaVacacionesPendientesUsuario = sv.listarPendientesUsuario();
        this.listaVacacionesRechazadasUsuario = sv.listarRechazadasUsuario(); 
    }

}
