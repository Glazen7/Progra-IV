
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import org.primefaces.PrimeFaces;

@ManagedBean(name = "ManagerController")
@SessionScoped
public class ManagerController implements Serializable {

    List<Manager> listaManager = new ArrayList<>();
    List<Manager> listaManagerIndividual = new ArrayList<>();
    List<UsuarioTO> listaUsuariosManager = new ArrayList<>();
    List<Vacaciones> listaVacacionesUsuariosManager = new ArrayList<>();
    private String fechaInicio, fechaFinal;
    UsuarioTO selectedUsuario = new UsuarioTO();
    List<Manager> lista = new ArrayList<>();
    ServicioUsuario sv = new ServicioUsuario();
    ServicioManager sm = new ServicioManager();
    private List<Vacaciones> listaVacacionesPendientesUsuarioManager = new ArrayList<>();
    private List<Vacaciones> listaVacacionesAprobadasUsuarioManager = new ArrayList<>();
    private List<Vacaciones> listaVacacionesRechazadasUsuarioManager = new ArrayList<>();
    private List<Permisos> listaPermisosPendientesUsuarioManager = new ArrayList<>();
    private List<Permisos> listaPermisosAprobadasUsuarioManager = new ArrayList<>();
    private List<Permisos> listaPermisosRechazadasUsuarioManager = new ArrayList<>();
    
    private List<Vacaciones> listaTemporal = new ArrayList<>();
    private List<Permisos> listaTemporalP = new ArrayList<>();
    ServicioVacaciones sva = new ServicioVacaciones();
    ServicioPermisos sp = new ServicioPermisos();
    private String motivo;
    private int filtro;
    private Manager selectedManager = new Manager();
    private Manager newManager = new Manager();
    private Integer id;
    private String correo;
    private String nombre;
    private String contrasena;
    private Integer idManager;
    private Integer diasVacacionesDisponibles = 0;
    private Integer diaVacacionesTomadas = 0;
    private Integer activo;
    private String usuarioCreacion;
    private Integer cedula;
    private String fechaInicioTrabajo;

    public String getMotivo() {
        return motivo;
    }

    public List<Permisos> getListaTemporalP() {
        return listaTemporalP;
    }

    public void setListaTemporalP(List<Permisos> listaTemporalP) {
        this.listaTemporalP = listaTemporalP;
    }

    
    public List<Permisos> getListaPermisosPendientesUsuarioManager() {
        return listaPermisosPendientesUsuarioManager;
    }

    public void setListaPermisosPendientesUsuarioManager(List<Permisos> listaPermisosPendientesUsuarioManager) {
        this.listaPermisosPendientesUsuarioManager = listaPermisosPendientesUsuarioManager;
    }

    public List<Permisos> getListaPermisosAprobadasUsuarioManager() {
        return listaPermisosAprobadasUsuarioManager;
    }

    public void setListaPermisosAprobadasUsuarioManager(List<Permisos> listaPermisosAprobadasUsuarioManager) {
        this.listaPermisosAprobadasUsuarioManager = listaPermisosAprobadasUsuarioManager;
    }

    public List<Permisos> getListaPermisosRechazadasUsuarioManager() {
        return listaPermisosRechazadasUsuarioManager;
    }

    public void setListaPermisosRechazadasUsuarioManager(List<Permisos> listaPermisosRechazadasUsuarioManager) {
        this.listaPermisosRechazadasUsuarioManager = listaPermisosRechazadasUsuarioManager;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(String fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public List<Vacaciones> getListaVacacionesPendientesUsuarioManager() {
        return listaVacacionesPendientesUsuarioManager;
    }

    public void setListaVacacionesPendientesUsuarioManager(List<Vacaciones> listaVacacionesPendientesUsuarioManager) {
        this.listaVacacionesPendientesUsuarioManager = listaVacacionesPendientesUsuarioManager;
    }

    public List<Vacaciones> getListaVacacionesAprobadasUsuarioManager() {
        return listaVacacionesAprobadasUsuarioManager;
    }

    public void setListaVacacionesAprobadasUsuarioManager(List<Vacaciones> listaVacacionesAprobadasUsuarioManager) {
        this.listaVacacionesAprobadasUsuarioManager = listaVacacionesAprobadasUsuarioManager;
    }

    public List<Vacaciones> getListaVacacionesRechazadasUsuarioManager() {
        return listaVacacionesRechazadasUsuarioManager;
    }

    public void setListaVacacionesRechazadasUsuarioManager(List<Vacaciones> listaVacacionesRechazadasUsuarioManager) {
        this.listaVacacionesRechazadasUsuarioManager = listaVacacionesRechazadasUsuarioManager;
    }

    public List<Vacaciones> getListaTemporal() {
        return listaTemporal;
    }

    public void setListaTemporal(List<Vacaciones> listaTemporal) {
        this.listaTemporal = listaTemporal;
    }

    public List<Vacaciones> getListaVacacionesUsuariosManager() {
        return listaVacacionesUsuariosManager;
    }

    public void setListaVacacionesUsuariosManager(List<Vacaciones> listaVacacionesUsuariosManager) {
        this.listaVacacionesUsuariosManager = listaVacacionesUsuariosManager;
    }

    public int getFiltro() {
        return filtro;
    }

    public void setFiltro(int filtro) {
        this.filtro = filtro;
    }

    public List<UsuarioTO> getListaUsuariosManager() {
        return listaUsuariosManager;
    }

    public void setListaUsuariosManager(List<UsuarioTO> listaUsuariosManager) {
        this.listaUsuariosManager = listaUsuariosManager;
    }

    public ManagerController() {
    }

    public List<Manager> getListaManagerIndividual() {
        return listaManagerIndividual;
    }

    public void setListaManagerIndividual(List<Manager> listaManagerIndividual) {
        this.listaManagerIndividual = listaManagerIndividual;
    }

    public Manager getNewManager() {
        return newManager;
    }

    public void setNewManager(Manager newManager) {
        this.newManager = newManager;
    }

    public Manager getSelectedManager() {
        return selectedManager;
    }

    public void setSelectedManager(Manager selectedManager) {
        this.selectedManager = selectedManager;
    }

    public List<Manager> getLista() {
        return lista;
    }

    public void setLista(List<Manager> lista) {
        this.lista = lista;
    }

    public void crearUsuario(UsuarioTO u) {
        sv.insertar(u);
    }

    public List<Manager> getListaManager() {
        return listaManager;
    }

    public void setListaManager(List<Manager> listaManager) {
        this.listaManager = listaManager;
    }

    public UsuarioTO getSelectedUsuario() {
        return selectedUsuario;
    }

    public void setSelectedUsuario(UsuarioTO selectedUsuario) {
        this.selectedUsuario = selectedUsuario;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Integer getIdManager() {
        return idManager;
    }

    public void setIdManager(Integer idManager) {
        this.idManager = idManager;
    }

    public Integer getDiasVacacionesDisponibles() {
        return diasVacacionesDisponibles;
    }

    public void setDiasVacacionesDisponibles(Integer diasVacacionesDisponibles) {
        this.diasVacacionesDisponibles = diasVacacionesDisponibles;
    }

    public Integer getDiaVacacionesTomadas() {
        return diaVacacionesTomadas;
    }

    public void setDiaVacacionesTomadas(Integer diaVacacionesTomadas) {
        this.diaVacacionesTomadas = diaVacacionesTomadas;
    }

    public Integer getActivo() {
        return activo;
    }

    public void setActivo(Integer activo) {
        this.activo = activo;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getFechaInicioTrabajo() {
        return fechaInicioTrabajo;
    }

    public void setFechaInicioTrabajo(String fechaInicioTrabajo) {
        this.fechaInicioTrabajo = fechaInicioTrabajo;
    }

    public ServicioUsuario getSv() {
        return sv;
    }

    public void setSv(ServicioUsuario sv) {
        this.sv = sv;
    }

    public void iniciar(String Correo) {
        this.listaManagerIndividual = sm.listarManagerPersonal(Correo);
        this.filtro = this.listaManagerIndividual.get(0).getId();
        this.listaUsuariosManager = sv.listarUsuariosPropios(filtro);
        PrimeFaces.current().ajax().update(":form");
    }

    public void insertPermiso(String correo) {
        Manager ma = this.listaManagerIndividual.get(0);
        sp.sacarDiasPermisosDispon(ma);
        sp.sacarDiasPermisosTomadas(ma, fechaInicio, fechaFinal, motivo);
        iniciar(correo);
    }

    public void iniciarManagerUsuario() {
            for (UsuarioTO u : listaUsuariosManager) {

                listaTemporal = sva.listarPendientesPersonal(u.getNombre());
                for (Vacaciones vacacion : listaTemporal) {
                    if (!this.listaVacacionesPendientesUsuarioManager.contains(vacacion)) {
                        this.listaVacacionesPendientesUsuarioManager.add(vacacion);
                    }
                }

                listaTemporal = sva.listarAprobadasPersonal(u.getNombre());
                for (Vacaciones vacacion : listaTemporal) {
                    if (!this.listaVacacionesAprobadasUsuarioManager.contains(vacacion)) {
                        this.listaVacacionesAprobadasUsuarioManager.add(vacacion);
                    }
                }

                listaTemporal = sva.listarRechazadasPersonal(u.getNombre());
                for (Vacaciones vacacion : listaTemporal) {
                    if (!this.listaVacacionesRechazadasUsuarioManager.contains(vacacion)) {
                        this.listaVacacionesRechazadasUsuarioManager.add(vacacion);
                    }
                }
            
        }
        PrimeFaces.current().ajax().update(":form");
    }
    
    public void iniciarPermisosUsuario() {
            for (UsuarioTO u : listaUsuariosManager) {

                listaTemporalP = sp.listarPendientesPersonal(u.getNombre());
                for (Permisos permiso : listaTemporalP) {
                    if (!this.listaPermisosPendientesUsuarioManager.contains(permiso)) {
                        this.listaPermisosPendientesUsuarioManager.add(permiso);
                    }
                }

                listaTemporalP = sp.listarAprobadasPersonal(u.getNombre());
                for (Permisos permiso : listaTemporalP) {
                    if (!this.listaPermisosAprobadasUsuarioManager.contains(permiso)) {
                        this.listaPermisosAprobadasUsuarioManager.add(permiso);
                    }
                }

                listaTemporalP = sp.listarRechazadasPersonal(u.getNombre());
                for (Permisos permiso : listaTemporalP) {
                    if (!this.listaPermisosRechazadasUsuarioManager.contains(permiso)) {
                        this.listaPermisosRechazadasUsuarioManager.add(permiso);
                    }
                }
            }
        
        PrimeFaces.current().ajax().update(":form");
    }

    public void actualizarListasUsuario() {
        for (UsuarioTO u : listaUsuariosManager) {
            listaTemporal = sva.listarPendientesPersonal(u.getNombre());
            this.listaVacacionesPendientesUsuarioManager.addAll(listaTemporal);

            listaTemporal = sva.listarAprobadasPersonal(u.getNombre());
            for (Vacaciones vacacion : listaTemporal) {
                if (!this.listaVacacionesAprobadasUsuarioManager.contains(vacacion)) {
                    this.listaVacacionesAprobadasUsuarioManager.add(vacacion);
                }
            }

            listaTemporal = sva.listarRechazadasPersonal(u.getNombre());
            for (Vacaciones vacacion : listaTemporal) {
                if (!this.listaVacacionesRechazadasUsuarioManager.contains(vacacion)) {
                    this.listaVacacionesRechazadasUsuarioManager.add(vacacion);
                }
            }
        }
        PrimeFaces.current().ajax().update(":form");
    }

    public void insertVacacion(String correo) {
        Manager m = this.listaManagerIndividual.get(0);
        sva.sacarDiasVacacionesDispon(m);
        sva.sacarDiasVacacionesTomadas(m, fechaInicio, fechaFinal);
        iniciar(correo);
    }

    @PostConstruct
    public void inicializar() {
        this.listaManager = sm.listar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void actualizarManager(Manager m) {
        sm.actualizar(m);
    }

    public void actualizarUsuario(UsuarioTO us) {
        sv.actualizar(us);
    }

    public void insertarManager(Manager m) {
        m.setActivo(1);
        sm.insertar(m);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void eliminarManager(Manager m) {
        sm.eliminar(m);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }

    public void saveManager(Manager ma) {
        sm.actualizarManagerPersonal(ma);
        inicializar();
        PrimeFaces.current().ajax().update(":form");
    }
}
