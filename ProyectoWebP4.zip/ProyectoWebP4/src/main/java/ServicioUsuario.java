
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicioUsuario extends Servicio implements Serializable {

    public List<UsuarioTO> listar() {
        List<UsuarioTO> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO");
            rs = ps.executeQuery();
            while (rs.next()) {
                UsuarioTO u = new UsuarioTO();
                int id = rs.getInt("id");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                String fecha = rs.getString("fechaInicioTrabajo");
                String usuarioCreacion = rs.getString("usuarioCreacion");
                int cedula = rs.getInt("cedula");
                int idManager = rs.getInt("idManager");
                int diasVacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                int diasVacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                int activo = rs.getInt("activo");
                u.setId(id);
                u.setCedula(cedula);
                u.setNombre(nombre);
                u.setCorreo(correo);
                u.setContrasena(contrasena);
                u.setIdManager(idManager);
                u.setDiasVacacionesDisponibles(diasVacacionesDisponibles);
                u.setDiasVacacionesTomadas(diasVacacionesTomadas);
                u.setActivo(activo);
                u.setFechaInicio(fecha);
                u.setUsuarioCreacion(usuarioCreacion);
                lista.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<UsuarioTO> listarUsuariosPropios(int filtro) {
        List<UsuarioTO> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO where idManager=?");
            ps.setInt(1, filtro);
            rs = ps.executeQuery();
            while (rs.next()) {
                UsuarioTO u = new UsuarioTO();
                int id = rs.getInt("id");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                String fechaInicio = rs.getString("fechaInicioTrabajo");
                String usuarioCreacion = rs.getString("usuarioCreacion");
                int cedula = rs.getInt("cedula");
                int idManager = rs.getInt("idManager");
                int diasVacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                int diasVacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                int activo = rs.getInt("activo");
                u.setId(id);
                u.setCedula(cedula);
                u.setNombre(nombre);
                u.setCorreo(correo);
                u.setContrasena(contrasena);
                u.setIdManager(idManager);
                u.setDiasVacacionesDisponibles(diasVacacionesDisponibles);
                u.setDiasVacacionesTomadas(diasVacacionesTomadas);
                u.setActivo(activo);
                u.setFechaInicio(fechaInicio);
                u.setUsuarioCreacion(usuarioCreacion);
                lista.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<UsuarioTO> listarIndividual(String us) {
        List<UsuarioTO> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO where nombre=?");
            ps.setString(1, us);
            rs = ps.executeQuery();
            while (rs.next()) {
                UsuarioTO u = new UsuarioTO();
                int id = rs.getInt("id");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                String fechaInicio = rs.getString("fechaInicioTrabajo");
                String usuarioCreacion = rs.getString("usuarioCreacion");
                int cedula = rs.getInt("cedula");
                int idManager = rs.getInt("idManager");
                int diasVacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                int diasVacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                int activo = rs.getInt("activo");
                u.setId(id);
                u.setCedula(cedula);
                u.setNombre(nombre);
                u.setCorreo(correo);
                u.setContrasena(contrasena);
                u.setIdManager(idManager);
                u.setDiasVacacionesDisponibles(diasVacacionesDisponibles);
                u.setDiasVacacionesTomadas(diasVacacionesTomadas);
                u.setActivo(activo);
                u.setFechaInicio(fechaInicio);
                u.setUsuarioCreacion(usuarioCreacion);
                lista.add(u);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public void insertar(UsuarioTO u) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("INSERT INTO usuario (nombre,correo,contrasena,idManager,diasVacacionesDisponibles,diasVacacionesTomadas,activo,usuarioCreacion,cedula,fechaInicioTrabajo) VALUES (?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getContrasena());
            ps.setInt(4, u.getIdManager());
            ps.setInt(5, u.getDiasVacacionesDisponibles());
            ps.setInt(6, u.getDiasVacacionesTomadas());
            ps.setInt(7, u.getActivo());
            ps.setString(8, u.getUsuarioCreacion());
            ps.setInt(9, u.getCedula());
            ps.setString(10, u.getFechaInicio());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void actualizar(UsuarioTO u) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE usuario SET nombre=?,correo=?,contrasena=?,idManager=?,diasVacacionesDisponibles=?,diasVacacionesTomadas=?, activo=?,usuarioCreacion=?, cedula=?, fechaInicioTrabajo=? WHERE id=?");
            ps.setString(1, u.getNombre());
            ps.setString(2, u.getCorreo());
            ps.setString(3, u.getContrasena());
            ps.setInt(4, u.getIdManager());
            ps.setInt(5, u.getDiasVacacionesDisponibles());
            ps.setInt(6, u.getDiasVacacionesTomadas());
            ps.setInt(7, u.getActivo());
            ps.setString(8, u.getUsuarioCreacion());
            ps.setInt(9, u.getCedula());
            ps.setString(10, u.getFechaInicio());
            ps.setInt(11, u.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void actualizarPersonal(UsuarioTO u) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE usuario SET cedula=?,nombre=?,correo=?,contrasena=? WHERE id=?");
            ps.setInt(1, u.getCedula());
            ps.setString(2, u.getNombre());
            ps.setString(3, u.getCorreo());
            ps.setString(4, u.getContrasena());
            ps.setInt(5, u.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void eliminar(UsuarioTO u) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("DELETE FROM usuario WHERE id = ?");
            ps.setInt(1, u.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public String buscarManagerAsignado(int idManagerResponsable) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        String nombreCompleto = "";
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO WHERE idManager =?");
            ps.setInt(1, idManagerResponsable);
            rs = ps.executeQuery();
            String nombre = rs.getString("nombre");
            nombreCompleto = nombre;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return nombreCompleto;
    }

    public String buscarCorreo(String nombre) {
        String correoResult = "";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = getConnection();

            // Buscar en la tabla "USUARIO"
            ps = conn.prepareStatement("SELECT correo FROM USUARIO WHERE nombre = ?");
            ps.setString(1, nombre);
            rs = ps.executeQuery();

            if (rs.next()) {
                correoResult = rs.getString("correo");
            } else {
                // Si no se encuentra en la tabla "USUARIO", buscar en la tabla "manager"
                ps = conn.prepareStatement("SELECT correo FROM manager WHERE nombre = ?");
                ps.setString(1, nombre);
                rs = ps.executeQuery();

                if (rs.next()) {
                    correoResult = rs.getString("correo");
                } else {
                    // Si no se encuentra en la tabla "manager", buscar en la tabla "administrador"
                    ps = conn.prepareStatement("SELECT correo FROM administrador WHERE nombre = ?");
                    ps.setString(1, nombre);
                    rs = ps.executeQuery();

                    if (rs.next()) {
                        correoResult = rs.getString("correo");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos en orden inverso
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return correoResult;
    }
    //metodo de comprobacion que retorne un usuario to, recibe por parametros correo y contrasena, select donde tal es tal y tal es tal, si eso existe(if.next) retornar un usuario.to, esto probarlo desde el main
}
