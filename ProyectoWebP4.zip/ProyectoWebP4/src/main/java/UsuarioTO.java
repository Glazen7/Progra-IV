import java.io.Serializable;

public class UsuarioTO implements Serializable{
    String correo, contrasena, nombre, usuarioCreacion, fechaInicio;
    int id, idManager, diasVacacionesTomadas, diasVacacionesDisponibles,activo,cedula;
    
    public UsuarioTO() {
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }
    
    
    public UsuarioTO(String contrasena, String nombre) {
        this.contrasena = contrasena;
        this.nombre = nombre;
    }

    public UsuarioTO(int id, String correo, String nombre, String contrasena, int idManager) {
        this.id=id;
        this.correo = correo;
        this.contrasena = contrasena;
        this.nombre = nombre;
        this.idManager=idManager;
    }
    public void crearColaborador(String correo, String contrasena, String nombre, int id, int idManager){
        UsuarioTO newU= new UsuarioTO();
        newU.setNombre(nombre);
        newU.setContrasena(contrasena);
        newU.setCorreo(correo);
        newU.setId(id);
        newU.setIdManager(idManager);
        ServicioUsuario su = new ServicioUsuario();
        su.insertar(newU);
    }
    public String getCorreo() {
        return correo;
    }
    
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdManager() {
        return idManager;
    }

    public void setIdManager(int idManager) {
        this.idManager = idManager;
    }

    public int getDiasVacacionesTomadas() {
        return diasVacacionesTomadas;
    }

    public void setDiasVacacionesTomadas(int diasVacacionesTomadas) {
        this.diasVacacionesTomadas = diasVacacionesTomadas;
    }

    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }

    public int getDiasVacacionesDisponibles() {
        return diasVacacionesDisponibles;
    }

    public void setDiasVacacionesDisponibles(int diasVacacionesDisponibles) {
        this.diasVacacionesDisponibles = diasVacacionesDisponibles;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
    
}
