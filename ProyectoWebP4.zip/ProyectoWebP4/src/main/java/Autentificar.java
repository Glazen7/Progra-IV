import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Autentificar extends Servicio implements Serializable {
    //implements serializable
    public Autentificar() {
    }
    //Los metodos autentificar diferencian entre si en el select, todos buscan dentro de su BD correspondiente, usuario/admin/manager
    //Metodo autentificar usuario obtiene el nombre y contrasena y los utiliza para verificar en la BD que exista un usuario de ese tipo
    public boolean autentificarUsuario(UsuarioTO u) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        ResultSet rs=null;
        boolean flag=false;
        UsuarioTO us= new UsuarioTO();
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO WHERE NOMBRE =?");
            ps.setString(1, u.getNombre());
            rs = ps.executeQuery();
            while (rs.next() && rs.getString("contrasena").equals(u.getContrasena())) {
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                us.setNombre(nombre);
                us.setContrasena(contrasena);
            }           
            if(u.getNombre().equals(us.getNombre()) && u.getContrasena().equals(us.getContrasena()) ){
                flag=true;
            }else{
                flag=false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return flag;
    }
    //Metodo autentificar administrador obtiene el nombre y contrasena y los utiliza para verificar en la BD que exista un administrador de ese tipo
    public boolean autentificarAdministrador(Administrador a) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        ResultSet rs=null;
        boolean flag=false;
        UsuarioTO us= new UsuarioTO();
        try {
            ps = conn.prepareStatement("SELECT * FROM ADMINISTRADOR WHERE NOMBRE =?");
            ps.setString(1, a.getNombre());
            rs = ps.executeQuery();
            while (rs.next() && rs.getString("contrasena").equals(a.getContrasena())) {
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                us.setNombre(nombre);
                us.setContrasena(contrasena);
            }           
            if(a.getNombre().equals(us.getNombre()) && a.getContrasena().equals(us.getContrasena()) ){
                flag=true;
            }else{
                flag=false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return flag;
    }
    //Metodo autentificar manager obtiene el nombre y contrasena y los utiliza para verificar en la BD que exista un manager de ese tipo
    public boolean autentificarManager(Manager g) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        ResultSet rs=null;
        boolean flag=false;
        UsuarioTO us= new UsuarioTO();
        try {
            ps = conn.prepareStatement("SELECT * FROM MANAGER WHERE NOMBRE =?");
            ps.setString(1, g.getNombre());
            rs = ps.executeQuery();
            while (rs.next() && rs.getString("contrasena").equals(g.getContrasena())) {
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                us.setNombre(nombre);
                us.setContrasena(contrasena);
            }           
            if(g.getNombre().equals(us.getNombre()) && g.getContrasena().equals(us.getContrasena()) ){
                flag=true;
            }else{
                flag=false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return flag;
    }
    //Autentificar login recibe 2 parametros, correo y contrasena, luego los pasa a cada uno de los autentificar, y si es de ese tipo devuelve un flag que determina de que tipo es
    public int autentificarLogin(UsuarioTO o,Administrador a, Manager m){
        int flag=0;
        if(autentificarUsuario(o)==true){
            flag=1;
        }       
        if(autentificarAdministrador(a)==true){
            flag=2;
        }
        if(autentificarManager(m)==true){
            flag=3;
        }
        return flag;
    }
}
