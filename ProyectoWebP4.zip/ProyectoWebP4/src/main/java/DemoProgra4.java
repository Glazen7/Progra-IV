import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class DemoProgra4 {
    public static void main(String[] args) {
        ServicioUsuario su = new ServicioUsuario();
        ServicioManager sm= new ServicioManager();
        ServicioAdministrador sa = new ServicioAdministrador();
        Autentificar auth = new Autentificar();
        UsuarioTO us = new UsuarioTO();
        UsuarioTO pcc = new UsuarioTO();
        Manager ma = new Manager();
        Administrador ad = new Administrador();
        Vacaciones vac = new Vacaciones();
        ServicioVacaciones sv = new ServicioVacaciones();
        EnviarCorreo ec = new EnviarCorreo();
        String mail= "marcoleonardo2018@gmail.com";
        ec.createEmailAceptados(mail, "2023-08-13-2023-08-15");
        ec.sendEmail();
        /*try{
            System.out.println("*----------------------------*");
            System.out.println("USUARIOS");
            for(UsuarioTO u : su.listar()){             
                System.out.println("El nombre es "+u.getNombre());
                System.out.println("El id es "+u.getId());
                System.out.println("El correo es "+u.getCorreo());
                System.out.println("La cedula es "+u.getCedula());
            }
            
            System.out.println("*----------------------------*");
            System.out.println("MANAGERS");
            for(Manager m :sm.listar()){                            
                System.out.println("El nombre es "+m.getNombre());
                System.out.println("El id es "+m.getId());
                System.out.println("El correo es "+m.getCorreo());
            }
            System.out.println("*----------------------------*");
            System.out.println("ADMINISTRADORES");
            for(Administrador a :sa.listar()){             
                //System.out.println("El id es "+u.getId());
                System.out.println("El nombre es "+a.getNombre());
                System.out.println("El id es "+a.getId());
                System.out.println("El correo es "+a.getCorreo());
            }
            System.out.println("*----------------------------*");
            System.out.println("VACACIONES");
            for(Vacaciones v : sv.listar()){             
                System.out.println("El id es "+v.getIdSolicitante());
                System.out.println("El nombre es "+v.getNombreSolicitante());       
                System.out.println("La cantidad de dias solicitados es "+v.getCantidadDiasSolicitados());
                System.out.println("La cantidad de dias disponibles es"+v.getCantidadDiasDisponibles());
                System.out.println("La fecha solicitada es "+v.getFechaSolicitada());   
            }*/
            
            /*
            vac.setIdSolicitante(2);
            vac.setNombreSolicitante("Prueba");
            vac.setFechaSolicitada("fechaaaa");
            vac.setCantidadDiasDisponibles(10);
            vac.setCantidadDiasSolicitados(3);
            sv.eliminar(vac);*/
            
            
            //probar serviciousuario
            /*us.setId(1);
            us.setCedula(604720990);
            us.setContrasena("3233");
            us.setNombre("Marco Perez");
            us.setCorreo("marco2018@gmail.com");
            us.setIdManager(5);
            us.setDiasVacacionesTomadas(6);
            us.setDiasVacacionesDisponibles(3);
            us.setActivo(1);
            System.out.println("*----------------------------*");
            System.out.println("LISTA INDIVIDUAL");
            for(UsuarioTO u : su.listarIndividual(us.getNombre())){             
                System.out.println("El nombre es "+u.getNombre());
                System.out.println("El id es "+u.getId());
                System.out.println("El correo es "+u.getCorreo());
                System.out.println("La cedula es "+u.getCedula());
            }*/
            //su.eliminar(us);
            
            
            /*int idPCC = 5;
            String nombrePCC = "PCCNombre";
            String contrasena= "12345";
            String correo = "correoPCC";
            pcc.crearColaborador(correo, contrasena, nombrePCC, idPCC, 0);
            System.out.println("Ejecutado pcc crear colaborador");
            */
            /*us.setNombre("Manager1");
            us.setContrasena("12345");
            ad.setNombre("Manager1");
            ad.setContrasena("12345");
            ma.setNombre("Manager1");
            ma.setContrasena("12345");
            
            if(auth.autentificarLogin(us,ad,ma)==1){
                System.out.println("Es un usuario");
            }
            if(auth.autentificarLogin(us,ad,ma)==2){
                System.out.println("Es un admin");
            }
            if(auth.autentificarLogin(us,ad,ma)==3){
                System.out.println("Es un manager");
            }
            if(auth.autentificarLogin(us,ad,ma)==0){
                System.out.println("Esta mal");
            }
            */
            /*if(auth.autentificarUsuario(us)==true){
                System.out.println("Validacion correcta");
            }else{
                System.out.println("Validacion incorrecta");
            }
            ma.setNombre("Manager1");
            ma.setContrasena("12345");
            if(auth.autentificarManager(ma)==true){
                System.out.println("Validacion correcta");
            }else{
                System.out.println("Validacion incorrecta");
            }*/
        //}catch(Exception e){
            //e.printStackTrace();
        //}
    }
}
