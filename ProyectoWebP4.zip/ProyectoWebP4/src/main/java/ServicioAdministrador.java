
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicioAdministrador extends Servicio implements Serializable{
    
    public  List<Administrador> listar() {
        List<Administrador> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM ADMINISTRADOR");
            rs = ps.executeQuery();
            while (rs.next()) {
                Administrador a = new Administrador();
                int id = rs.getInt("id");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                int activo = rs.getInt("activo");
                int cedula = rs.getInt("cedula");
                a.setId(id);
                a.setNombre(nombre);
                a.setCorreo(correo);
                a.setContrasena(contrasena);
                a.setActivo(activo);
                a.setCedula(cedula);
                lista.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    public  List<Administrador> listarAdministradorPropio(String identifier) {
        List<Administrador> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM ADMINISTRADOR where nombre=?");
            ps.setString(1, identifier);
            rs = ps.executeQuery();
            while (rs.next()) {
                Administrador a = new Administrador();
                int id = rs.getInt("id");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                int activo = rs.getInt("activo");
                int cedula = rs.getInt("cedula");
                a.setId(id);
                a.setNombre(nombre);
                a.setCorreo(correo);
                a.setContrasena(contrasena);
                a.setActivo(activo);
                a.setCedula(cedula);
                lista.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public void insertar(Administrador a) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("INSERT INTO administrador (correo,contrasena,nombre,cedula,activo) VALUES (?,?,?,?,?)");
            ps.setString(1, a.getCorreo());
            ps.setString(2, a.getContrasena());
            ps.setString(3, a.getNombre());
            ps.setInt(4, a.getCedula());
            ps.setInt(5, a.getActivo());           
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void actualizar(Administrador a) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE administrador SET correo=?, contrasena=?, nombre=?, cedula=?, activo=? WHERE id=?");
            ps.setString(1, a.getCorreo());
            ps.setString(2, a.getContrasena());
            ps.setString(3, a.getNombre());
            ps.setInt(4, a.getCedula());
            ps.setInt(5, a.getActivo());
            ps.setInt(6, a.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminar(Administrador a) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("DELETE FROM administrador WHERE id = ?");
            ps.setInt(1, a.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
