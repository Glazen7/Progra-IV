
import java.io.Serializable;

public class Manager implements Serializable{
    String correo, contrasena, nombre,usuarioCreacion, fechaInicioTrabajo;
    int id, idAdmin, cedula, diasDisponiblesVacaciones, diasDisponiblesTomadas, activo;

    public Manager() {
    }

    public String getFechaInicioTrabajo() {
        return fechaInicioTrabajo;
    }

    public void setFechaInicioTrabajo(String fechaInicioTrabajo) {
        this.fechaInicioTrabajo = fechaInicioTrabajo;
    }
    
    
    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public int getDiasDisponiblesVacaciones() {
        return diasDisponiblesVacaciones;
    }

    public void setDiasDisponiblesVacaciones(int diasDisponiblesVacaciones) {
        this.diasDisponiblesVacaciones = diasDisponiblesVacaciones;
    }

    public int getDiasDisponiblesTomadas() {
        return diasDisponiblesTomadas;
    }

    public void setDiasDisponiblesTomadas(int diasDisponiblesTomadas) {
        this.diasDisponiblesTomadas = diasDisponiblesTomadas;
    }

    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
    
}
