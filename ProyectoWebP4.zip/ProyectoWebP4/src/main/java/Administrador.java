
import java.io.Serializable;

public class Administrador implements Serializable {

    String correo, contrasena, nombre;
    int id, cedula, activo;

    public Administrador() {
    }

    public Administrador(String correo, String contrasena, String nombre, String apellidos, int id, int cedula) {
        this.correo = correo;
        this.contrasena = contrasena;
        this.nombre = nombre;
        this.id = id;
        this.cedula = cedula;
    }

    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public UsuarioTO crearColaborador() {
        UsuarioTO u = new UsuarioTO();
        return u;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
}
