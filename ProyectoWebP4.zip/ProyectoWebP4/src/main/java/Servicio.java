
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Servicio implements Serializable {

    private transient Connection conn;

    protected Connection getConnection() {
        conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/progra4?serverTimezone=UTC", "root", "HorseRider7!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    protected void cerrarRS(ResultSet rs) throws Exception {
        if (rs != null && !rs.isClosed()) {
            rs.close();
            rs = null;
        }
    }

    protected void cerrarPS(PreparedStatement ps) throws Exception {
        if (ps != null && !ps.isClosed()) {
            ps.close();
            ps = null;
        }
    }

    protected void cerrarConn(Connection conn) throws Exception {
        if (conn != null && !conn.isClosed()) {
            conn.close();
            conn = null;
        }
    }

}
