
import java.io.Serializable;

public class Vacaciones implements Serializable{
    int idSolicitante, idSolicitud, cantidadDiasSolicitados, cantidadDiasDisponibles, estado, requestType;
    String fechaSolicitada, nombreSolicitante;

    public Vacaciones() {
    }

    public int getRequestType() {
        return requestType;
    }

    public void setRequestType(int requestType) {
        this.requestType = requestType;
    }

    public int getIdSolicitud() {
        return idSolicitud;
    }

    public void setIdSolicitud(int idSolicitud) {
        this.idSolicitud = idSolicitud;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getIdSolicitante() {
        return idSolicitante;
    }

    public void setIdSolicitante(int idSolicitante) {
        this.idSolicitante = idSolicitante;
    }

    public String getFechaSolicitada() {
        return fechaSolicitada;
    }

    public void setFechaSolicitada(String fechaSolicitada) {
        this.fechaSolicitada = fechaSolicitada;
    }

    public String getNombreSolicitante() {
        return nombreSolicitante;
    }

    public void setNombreSolicitante(String nombreSolicitante) {
        this.nombreSolicitante = nombreSolicitante;
    }

    public int getCantidadDiasSolicitados() {
        return cantidadDiasSolicitados;
    }

    public void setCantidadDiasSolicitados(int cantidadDiasSolicitados) {
        this.cantidadDiasSolicitados = cantidadDiasSolicitados;
    }

    public int getCantidadDiasDisponibles() {
        return cantidadDiasDisponibles;
    }

    public void setCantidadDiasDisponibles(int cantidadDiasDisponibles) {
        this.cantidadDiasDisponibles = cantidadDiasDisponibles;
    }
    
}
