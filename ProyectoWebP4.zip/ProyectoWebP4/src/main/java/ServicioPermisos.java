
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ServicioPermisos extends Servicio implements Serializable {

    public List<Permisos> listar() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarPendientesManager() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=0 and requestType=1");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarPendientesUsuario() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=0 and requestType=2");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public List<Permisos> listarPendientesAdministrador() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=0 and requestType=3");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarPendientes() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=0");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarPendientesPersonal(String filtro) {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=0 and nombreSolicitante=?");
            ps.setString(1, filtro);
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarRechazadas() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=2");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarRechazadasManager() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=2 and requestType=1");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarRechazadasUsuario() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=2 and requestType=2");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public List<Permisos> listarRechazadasAdministrador() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=2 and requestType=3");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarRechazadasPersonal(String filtro) {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=2 and nombreSolicitante=?");
            ps.setString(1, filtro);
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarAprobadas() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=1");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarAprobadasManager() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=1 and requestType=1");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public List<Permisos> listarAprobadasAdminitrador() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=1 and requestType=3");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarAprobadasUsuario() {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=1 and requestType=2");
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public List<Permisos> listarAprobadasPersonal(String filtro) {
        List<Permisos> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM permisos WHERE estado=1 and nombreSolicitante=?");
            ps.setString(1, filtro);
            rs = ps.executeQuery();
            while (rs.next()) {
                Permisos p = new Permisos();
                int idSolicitud = rs.getInt("idSolicitud");
                int idSolicitante = rs.getInt("idSolicitante");
                int cantidadDiasSolicitados = rs.getInt("cantidadDiasSolicitados");
                int cantidadDiasDisponibles = rs.getInt("cantidadDiasDisponibles");
                int estado = rs.getInt("estado");
                int requestType = rs.getInt("requestType");
                String fechaSolicitada = rs.getString("fechaSolicitada");
                String nombreSolicitante = rs.getString("nombreSolicitante");
                String razonPermiso = rs.getString("razonPermiso");
                p.setIdSolicitante(idSolicitante);
                p.setNombreSolicitante(nombreSolicitante);
                p.setCantidadDiasSolicitados(cantidadDiasSolicitados);
                p.setFechaSolicitada(fechaSolicitada);
                p.setCantidadDiasDisponibles(cantidadDiasDisponibles);
                p.setEstado(estado);
                p.setIdSolicitud(idSolicitud);
                p.setRequestType(requestType);
                p.setRazonPermiso(razonPermiso);
                lista.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }

    public void insertar(Permisos p) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("INSERT INTO permisos ( idSolicitud, idSolicitante,nombreSolicitante,cantidadDiasSolicitados,cantidadDiasDisponibles,fechaSolicitada,razonPermiso,estado,requestType) VALUES (?,?,?,?,?,?,?,?,?)");
            ps.setInt(1, p.getIdSolicitud());
            ps.setInt(2, p.getIdSolicitante());
            ps.setString(3, p.getNombreSolicitante());
            ps.setInt(4, p.getCantidadDiasSolicitados());
            ps.setInt(5, p.getCantidadDiasDisponibles());
            ps.setString(6, p.getRazonPermiso());
            ps.setString(7, p.getFechaSolicitada());
            ps.setInt(8, p.getEstado());
            ps.setInt(9, p.getRequestType());

            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void actualizar(Permisos p) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE permisos SET idSolicitante=?, nombreSolicitante=?,cantidadDiasSolicitados=?, cantidadDiasDisponibles=?, fechaSolicitada=?, razonPermiso=?, estado=?, requestType=? WHERE idSolicitud=?");
            ps.setInt(1, p.getIdSolicitante());
            ps.setString(2, p.getNombreSolicitante());
            ps.setInt(3, p.getCantidadDiasSolicitados());
            ps.setInt(4, p.getCantidadDiasDisponibles());
            ps.setString(5, p.getFechaSolicitada());
            ps.setString(6, p.getRazonPermiso());
            ps.setInt(7, p.getEstado());
            ps.setInt(8, p.getRequestType());
            ps.setInt(9, p.getIdSolicitud());

            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void actualizarSolicitud(Permisos p, int estado) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE permisos SET estado=? WHERE idSolicitud=?");
            ps.setInt(1, estado);
            ps.setInt(2, p.getIdSolicitud());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void eliminar(Permisos p) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("DELETE FROM permisos WHERE idSolicitud = ?");
            ps.setInt(1, p.getIdSolicitud());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void sacarDiasPermisosDispon(UsuarioTO u) {
        ResultSet rs = null;
        PreparedStatement ps = null;
        Connection conn = getConnection();
        int vacacionesDisponibles = 0;
        int vacacionesTomadas = 0;
        int cantidadDiasDisponibles = 0;

        //Creamos una variable para obtener la fecha actual
        LocalDate primeraFecha = LocalDate.parse(u.fechaInicio);

        //Hacemos un casteo por que necesitamos trabajar con un string
        String fechaActual = LocalDate.now().toString();

        try {
            //Creamos objetos de tipo calendario que almacenaran los datos
            Calendar inicio = new GregorianCalendar();
            Calendar fin = new GregorianCalendar();
            //Le pasamos a inicio la fecha en que se creo el usuario
            inicio.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(u.fechaInicio));
            //Le pasamos la fecha actual
            fin.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(fechaActual));
            //creamos una variable para saber cuanta diferencia de años tiene
            int difA = fin.get(Calendar.YEAR) - inicio.get(Calendar.YEAR);
            /*
            Multiplicamos por 12 la diferencia de anios entre las dos fechas y les suamamos la cantidad de meses de la segunda fecha
            y luego le restamos el numero de mes de la primera fecha y asi obtener la diferencia de los meses
             */
            cantidadDiasDisponibles = difA * 12 + fin.get(Calendar.MONTH) - inicio.get(Calendar.MONTH);
        } catch (java.text.ParseException ex) {
            Logger.getLogger(ServicioVacaciones.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO where id=?");
            ps.setInt(1, u.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                vacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                cantidadDiasDisponibles = cantidadDiasDisponibles - vacacionesTomadas;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            ps = conn.prepareStatement("UPDATE usuario SET diasVacacionesDisponibles=? WHERE id=?");
            ps.setInt(1, cantidadDiasDisponibles);
            ps.setInt(2, u.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void sacarDiasPermisosTomadas(UsuarioTO u, String fechaInicioSolicitud, String fechaFinalSolicitud, String motivo) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        int vacacionesDisponibles = 0;
        int vacacionesTomadas = 0;
        LocalDate fechaInicio = LocalDate.parse(fechaInicioSolicitud);
        LocalDate fechaFinal = LocalDate.parse(fechaFinalSolicitud);
        Period periodo = Period.between(fechaInicio, fechaFinal);
        int diasEntreFechas = periodo.getDays();

        try {
            ps = conn.prepareStatement("SELECT * FROM USUARIO where id=?");
            ps.setInt(1, u.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                vacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                vacacionesTomadas = rs.getInt("diasVacacionesTomadas");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (vacacionesDisponibles == 0) {
            JOptionPane.showMessageDialog(null, "Usted no tiene dias para permisos disponibles");
        } else {
            if (vacacionesDisponibles < diasEntreFechas) {
                JOptionPane.showMessageDialog(null, "La cantidad de dias solicitados excede los dias disponibles");
            } else {
                int cantidadDiasDisponibles = vacacionesDisponibles - diasEntreFechas;
                int cantidadDiasTomados = diasEntreFechas + vacacionesTomadas;
                try {
                    ps = conn.prepareStatement("UPDATE usuario SET diasVacacionesDisponibles=?, diasVacacionesTomadas=? WHERE id=?");
                    ps.setInt(1, cantidadDiasDisponibles);
                    ps.setInt(2, cantidadDiasTomados);
                    ps.setInt(3, u.getId());
                    ps.executeUpdate();
                    ps = conn.prepareStatement("INSERT INTO permisos (idSolicitante,nombreSolicitante,cantidadDiasSolicitados,cantidadDiasDisponibles,fechaSolicitada,razonPermiso,estado,requestType) VALUES (?,?,?,?,?,?,?,?)");
                    ps.setInt(1, u.getCedula());
                    ps.setString(2, u.getNombre());
                    ps.setInt(3, diasEntreFechas);
                    ps.setInt(4, cantidadDiasDisponibles);
                    ps.setString(5, fechaInicioSolicitud + "-" + fechaFinalSolicitud);
                    ps.setString(6, motivo);
                    ps.setInt(7, 0);
                    ps.setInt(8, 2);
                    ps.executeUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        cerrarPS(ps);
                        cerrarConn(conn);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void sacarDiasPermisosDispon(Manager m) {
        ResultSet rs = null;
        PreparedStatement ps = null;
        Connection conn = getConnection();
        int vacacionesDisponibles = 0;
        int vacacionesTomadas = 0;
        int cantidadDiasDisponibles = 0;

        //Creamos una variable para obtener la fecha actual
        LocalDate primeraFecha = LocalDate.parse(m.fechaInicioTrabajo);

        //Hacemos un casteo por que necesitamos trabajar con un string
        String fechaActual = LocalDate.now().toString();

        try {
            //Creamos objetos de tipo calendario que almacenaran los datos
            Calendar inicio = new GregorianCalendar();
            Calendar fin = new GregorianCalendar();
            //Le pasamos a inicio la fecha en que se creo el usuario
            inicio.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(m.fechaInicioTrabajo));
            //Le pasamos la fecha actual
            fin.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(fechaActual));
            //creamos una variable para saber cuanta diferencia de años tiene
            int difA = fin.get(Calendar.YEAR) - inicio.get(Calendar.YEAR);
            /*
            Multiplicamos por 12 la diferencia de anios entre las dos fechas y les suamamos la cantidad de meses de la segunda fecha
            y luego le restamos el numero de mes de la primera fecha y asi obtener la diferencia de los meses
             */
            cantidadDiasDisponibles = difA * 12 + fin.get(Calendar.MONTH) - inicio.get(Calendar.MONTH);
        } catch (java.text.ParseException ex) {
            Logger.getLogger(ServicioVacaciones.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ps = conn.prepareStatement("SELECT * FROM manager where id=?");
            ps.setInt(1, m.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                vacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                cantidadDiasDisponibles = cantidadDiasDisponibles - vacacionesTomadas;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            ps = conn.prepareStatement("UPDATE manager SET diasVacacionesDisponibles=? WHERE id=?");
            ps.setInt(1, cantidadDiasDisponibles);
            ps.setInt(2, m.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void sacarDiasPermisosTomadas(Manager m, String fechaInicioSolicitud, String fechaFinalSolicitud, String motivo) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        int vacacionesDisponibles = 0;
        int vacacionesTomadas = 0;
        LocalDate fechaInicio = LocalDate.parse(fechaInicioSolicitud);
        LocalDate fechaFinal = LocalDate.parse(fechaFinalSolicitud);
        Period periodo = Period.between(fechaInicio, fechaFinal);
        int diasEntreFechas = periodo.getDays();

        try {
            ps = conn.prepareStatement("SELECT * FROM manager where id=?");
            ps.setInt(1, m.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                vacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                vacacionesTomadas = rs.getInt("diasVacacionesTomadas");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (vacacionesDisponibles == 0) {
            JOptionPane.showMessageDialog(null, "Usted no tiene dias para permisos disponibles");
        } else {
            if (vacacionesDisponibles < diasEntreFechas) {
                JOptionPane.showMessageDialog(null, "La cantidad de dias solicitados excede los dias disponibles");
            } else {
                int cantidadDiasDisponibles = vacacionesDisponibles - diasEntreFechas;
                int cantidadDiasTomados = diasEntreFechas + vacacionesTomadas;
                try {
                    ps = conn.prepareStatement("UPDATE manager SET diasVacacionesDisponibles=?, diasVacacionesTomadas=? WHERE id=?");
                    ps.setInt(1, cantidadDiasDisponibles);
                    ps.setInt(2, cantidadDiasTomados);
                    ps.setInt(3, m.getId());
                    ps.executeUpdate();
                    ps = conn.prepareStatement("INSERT INTO permisos (idSolicitante,nombreSolicitante,cantidadDiasSolicitados,cantidadDiasDisponibles,fechaSolicitada,razonPermiso,estado,requestType) VALUES (?,?,?,?,?,?,?,?)");
                    ps.setInt(1, m.getCedula());
                    ps.setString(2, m.getNombre());
                    ps.setInt(3, diasEntreFechas);
                    ps.setInt(4, cantidadDiasDisponibles);
                    ps.setString(5, fechaInicioSolicitud + "-" + fechaFinalSolicitud);
                    ps.setString(6, motivo);
                    ps.setInt(7, 0);
                    ps.setInt(8, 1);
                    ps.executeUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        cerrarPS(ps);
                        cerrarConn(conn);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
    public void sacarPermisosAdministradores(Administrador a, String fechaInicioSolicitud, String fechaFinalSolicitud, String motivo) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        int vacacionesDisponibles = 0;
        LocalDate fechaInicio = LocalDate.parse(fechaInicioSolicitud);
        LocalDate fechaFinal = LocalDate.parse(fechaFinalSolicitud);
        Period periodo = Period.between(fechaInicio, fechaFinal);
        int diasEntreFechas = periodo.getDays();
        try {
            ps = conn.prepareStatement("INSERT INTO permisos (idSolicitante,nombreSolicitante,cantidadDiasSolicitados,cantidadDiasDisponibles,fechaSolicitada,razonPermiso, estado,requestType) VALUES (?,?,?,?,?,?,?,?)");
            ps.setInt(1, a.getCedula());
            ps.setString(2, a.getNombre());
            ps.setInt(3, diasEntreFechas);
            ps.setInt(4, vacacionesDisponibles);
            ps.setString(5, fechaInicioSolicitud + "-" + fechaFinalSolicitud);
            ps.setString(6, motivo);
            ps.setInt(7, 0);
            ps.setInt(8, 3);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
