
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ServicioManager extends Servicio implements Serializable{
    
    public  List<Manager> listar() {
        List<Manager> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM MANAGER");
            rs = ps.executeQuery();
            while (rs.next()) {
                Manager m = new Manager();
                int id = rs.getInt("id");
                int idAdmin = rs.getInt("idAdmin");
                int Cedula = rs.getInt("Cedula");
                int diasVacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                int diasVacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                int activo = rs.getInt("activo");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                String usuarioCreacion = rs.getString("usuarioCreacion");
                String fechaInicio = rs.getString("fechaInicioTrabajo");
                m.setId(id);
                m.setIdAdmin(idAdmin);
                m.setCedula(Cedula);
                m.setDiasDisponiblesVacaciones(diasVacacionesDisponibles);
                m.setDiasDisponiblesTomadas(diasVacacionesTomadas);
                m.setActivo(activo);
                m.setUsuarioCreacion(usuarioCreacion);
                m.setNombre(nombre);
                m.setCorreo(correo);
                m.setContrasena(contrasena);
                m.setFechaInicioTrabajo(fechaInicio);
                lista.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    public  List<Manager> listarManagerPersonal(String filtro) {
        List<Manager> lista = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("SELECT * FROM MANAGER where nombre=?");
            ps.setString(1, filtro);
            rs = ps.executeQuery();
            while (rs.next()) {
                Manager m = new Manager();
                int id = rs.getInt("id");
                int idAdmin = rs.getInt("idAdmin");
                int Cedula = rs.getInt("Cedula");
                int diasVacacionesDisponibles = rs.getInt("diasVacacionesDisponibles");
                int diasVacacionesTomadas = rs.getInt("diasVacacionesTomadas");
                int activo = rs.getInt("activo");
                String correo = rs.getString("correo");
                String nombre = rs.getString("nombre");
                String contrasena = rs.getString("contrasena");
                String usuarioCreacion = rs.getString("usuarioCreacion");
                String fechaInicio = rs.getString("fechaInicioTrabajo");
                m.setId(id);
                m.setIdAdmin(idAdmin);
                m.setCedula(Cedula);
                m.setDiasDisponiblesVacaciones(diasVacacionesDisponibles);
                m.setDiasDisponiblesTomadas(diasVacacionesTomadas);
                m.setActivo(activo);
                m.setUsuarioCreacion(usuarioCreacion);
                m.setNombre(nombre);
                m.setCorreo(correo);
                m.setContrasena(contrasena);
                m.setFechaInicioTrabajo(fechaInicio);
                lista.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarRS(rs);
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return lista;
    }
    
    public void insertar(Manager m) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("INSERT INTO manager (correo,contrasena,nombre,idAdmin,cedula, usuarioCreacion,diasVacacionesDisponibles,diasVacacionesTomadas,activo,fechaInicioTrabajo) VALUES (?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, m.getCorreo());
            ps.setString(2, m.getContrasena());
            ps.setString(3, m.getNombre());
            ps.setInt(4, m.getIdAdmin());
            ps.setInt(5, m.getCedula());
            ps.setString(6, m.getUsuarioCreacion());
            ps.setInt(7, m.getDiasDisponiblesVacaciones());
            ps.setInt(8, m.getDiasDisponiblesTomadas());
            ps.setInt(9, m.getActivo());
            ps.setString(10, m.getFechaInicioTrabajo());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void actualizar(Manager m) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE manager SET correo=?,contrasena=?,nombre=?, idAdmin=?, cedula=?, usuarioCreacion=?, diasVacacionesDisponibles=?, diasVacacionesTomadas=?, activo=?, fechaInicioTrabajo=? WHERE id=?");       
            ps.setString(1, m.getCorreo());
            ps.setString(2, m.getContrasena());
            ps.setString(3, m.getNombre());
            ps.setInt(4, m.getIdAdmin());
            ps.setInt(5, m.getCedula());
            ps.setString(6, m.getUsuarioCreacion());
            ps.setInt(7, m.getDiasDisponiblesVacaciones());
            ps.setInt(8, m.getDiasDisponiblesTomadas());
            ps.setInt(9, m.getActivo());
            ps.setString(10, m.getFechaInicioTrabajo());
            ps.setInt(11, m.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void actualizarManagerPersonal(Manager m) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("UPDATE manager SET cedula=?,nombre=?,correo=?,contrasena=? WHERE id=?");       
            ps.setInt(1, m.getCedula());
            ps.setString(2, m.getNombre());
            ps.setString(3, m.getCorreo());
            ps.setString(4, m.getContrasena());
            ps.setInt(5, m.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void eliminar(Manager m) {
        PreparedStatement ps = null;
        Connection conn = getConnection();
        try {
            ps = conn.prepareStatement("DELETE FROM manager WHERE id = ?");
            ps.setInt(1, m.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                cerrarPS(ps);
                cerrarConn(conn);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
