package com.mycompany.chiquitinasmarco;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ChiquitinasMarco {
    public static List<Cliente> listC = new ArrayList<>();
    public static List<Orden> listO = new ArrayList<>();
    public static List<Item> listIte = new ArrayList<>();
    public static Scanner sc= new Scanner(System.in);
    public static int opcion,op,i,x;

    public static void main(String[] args) {
        System.out.println("Bienvenido al programa");
        do{
            System.out.println("Digite 1 si desea crear un cliente, 2 si desea ver los datos de un cliente"
                    + "3 si desea crear una orden, 4 si desea imprimir las ordenes");
            op=sc.nextInt();
            switch(op){
                case 1-> crearCliente();
                case 2-> leerCliente();
                case 3-> asignarOrden();
                case 4-> imprimirOrdenes();    
                case 5-> System.out.println("Case 5");
            }
        }while(op!=6);
    }
    public static void asignarOrden(){
        int idLeer;
        System.out.println("Digite el id del cliente al que desea anadir una orden");
        idLeer=sc.nextInt();
        for(int z=0; z<listC.size();z++){
            if(idLeer==listC.get(z).getId()){
               Orden o = new Orden(listC.get(z).getId());
               o=o.crearOrden();
               listO.add(o);
               o.arreglo();
            }
        }
        sendMail();
    }
    public static void imprimirOrdenes(){
        int idLeer;
        System.out.println("Digite el id del cliente del cual desea ver las ordenes");
        idLeer=sc.nextInt();
        Orden o = new Orden(idLeer);
        //Metodo leer me podria pedir una lista por parametro y le paso esta
        o.setListO(listO);
        o.setListIt(listIte);
        o.leerOrden(idLeer);
    }
    public static void sendMail(){
        System.out.println("se envio el correo ");
    }

    public static void crearCliente(){
        System.out.println("Si el cliente es una persona fisica digite 1, si es juridica digite 2");
            opcion=sc.nextInt();
            if(opcion==1){
                Cliente c = new PersonaFisica();
                listC.add(i, c);
                i++;
            }
            if(opcion==2){
                Cliente c = new PersonaJuridica();
                listC.add(i, c);
                i++;
            }   
    }
    public static void leerCliente(){ 
        int idLeer;
        System.out.println("Digite el id del cliente que desea imprimir");
        idLeer=sc.nextInt();
        for(int z=0; z<listC.size();z++){
            if(idLeer==listC.get(z).getId()){
                System.out.println("Cliente numero "+(z+1));
                System.out.println("Id "+listC.get(z).getId());
                System.out.println("Nombre "+listC.get(z).getNombre());
                System.out.println("Direccion "+listC.get(z).getDireccion());
                System.out.println("Correo "+listC.get(z).getCorreo());
                if(listC.get(z).getContactoResponsable()!=null){
                    System.out.println("El correo del contacto responsable de la cuenta es "+ listC.get(z).getContactoResponsable());
                }
            }
        }
    }

    public List<Cliente> getListC() {
        return listC;
    }

    public static void setListC(List<Cliente> listC) {
        ChiquitinasMarco.listC = listC;
    }

    public static void setListI(List<Item> listI) {
        ChiquitinasMarco.listIte = listI;
    }

    public static List<Item> getListI() {
        return listIte;
    }
    
}
