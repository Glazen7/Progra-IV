package com.mycompany.chiquitinasmarco;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Item {
    Scanner sc = new Scanner(System.in);
    int consecutivo,cantidadProducto,idP,precioP;
    String nombreP,descripcionP;
    List<Producto> listP = new ArrayList<>();
    List<Item> listI = new ArrayList<>();
    Producto p = new Producto();
    public Item() {  
        
    }
    public void crearItem(){
        Item a = new Item();
        Item b = new Item();
        p.crearProductos();
        listP=p.getListP();
        a.setConsecutivo(0001);
        a.setCantidadProducto(1);
        a.setIdP(listP.get(0).getId());
        a.setPrecioP(listP.get(0).getPrecio());
        a.setNombreP(listP.get(0).getNombre());
        a.setDescripcionP(listP.get(0).getDescripcion());
        b.setConsecutivo(0002);
        b.setCantidadProducto(4);
        b.setIdP(listP.get(1).getId());
        b.setPrecioP(listP.get(1).getPrecio());
        b.setNombreP(listP.get(1).getNombre());
        b.setDescripcionP(listP.get(1).getDescripcion());
        listI.add(a);
        listI.add(b);
    }
    
    public void leerItem(){
        int x = 0;
        System.out.println("producto ");
        for(Item e: listI){
            System.out.println("Consecutivo "+e.getConsecutivo());
            System.out.println("Cantidad producto "+e.getCantidadProducto());
            System.out.println("Id "+listP.get(x).getId());        
            System.out.println("Nombre "+listP.get(x).getNombre());
            System.out.println("Descripcion "+listP.get(x).getDescripcion());
            System.out.println("Precio "+listP.get(x).getPrecio());
            x++;
        }
        /*
        for(Producto z: listP){
            System.out.println("Id "+z.getId());
            System.out.println("Nombre "+z.getNombre());
            System.out.println("Descripcion "+z.getDescripcion());
            System.out.println("Precio "+z.getPrecio());
        }
        */
    }
    public void establecerCantidad(){
        System.out.println("Digite la cantidad del producto");
        cantidadProducto=sc.nextInt();
    }
    public void setConsecutivo(int consecutivo) {
        this.consecutivo = consecutivo;
    }

    public void setCantidadProducto(int cantidadProducto) {
        this.cantidadProducto = cantidadProducto;
    }

    public void setListP(List<Producto> listPe) {
        this.listP = listPe;
    }
    
    public void setListI(List<Item> listI) {
        this.listI = listI;
    }
    
    public int getConsecutivo() {
        return consecutivo;
    }

    public int getCantidadProducto() {
        return cantidadProducto;
    }

    public List<Item> getListI() {
        return listI;
    }

    public void setIdP(int idP) {
        this.idP = idP;
    }

    public void setPrecioP(int precioP) {
        this.precioP = precioP;
    }

    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }

    public void setDescripcionP(String descripcionP) {
        this.descripcionP = descripcionP;
    }

    public int getIdP() {
        return idP;
    }

    public int getPrecioP() {
        return precioP;
    }

    public String getNombreP() {
        return nombreP;
    }

    public String getDescripcionP() {
        return descripcionP;
    }
    
}
