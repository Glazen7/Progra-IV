
package com.mycompany.chiquitinasmarco;
import java.util.Scanner;
import java.util.List;

public class PersonaFisica extends Cliente{

    public PersonaFisica() {
        establecerPersona();
    }
    
    Scanner sc = new Scanner(System.in);
    
    public void setListO(List<Orden> listO) {
        this.listO = listO;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public List<Orden> getListO() {
        return listO;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getCorreo() {
        return correo;
    }
    
    
    @Override
    public void establecerPersona() {
        System.out.println("Digite el id del cliente ");
        id=sc.nextInt();
        System.out.println("Digite el nombre del cliente ");
        nombre=sc.next();
        System.out.println("Digite la direccion del cliente ");
        direccion=sc.next();
        System.out.println("Digite la direccion de correo del cliente ");
        correo=sc.next();
    }
}
