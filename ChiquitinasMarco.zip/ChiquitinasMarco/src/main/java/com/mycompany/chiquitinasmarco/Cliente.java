package com.mycompany.chiquitinasmarco;
import static com.mycompany.chiquitinasmarco.ChiquitinasMarco.sc;
import java.util.ArrayList;
import java.util.List;

public class Cliente {
    List<Orden> listO = new ArrayList<>();
    int id;
    String nombre;
    String direccion;
    String correo;
    String contactoResponsable;
    public void establecerPersona() {
    }
    
    public void setListO(List<Orden> listO) {
        this.listO = listO;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public List<Orden> getListO() {
        return listO;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public String getContactoResponsable() {
        return contactoResponsable;
    }

    public void setContactoResponsable(String contactoResponsable) {
        this.contactoResponsable = contactoResponsable;
    }
    
}
