package com.mycompany.chiquitinasmarco;
import java.util.ArrayList;
import java.util.List;

public class Producto {

    List<Producto> listP = new ArrayList<>();
    String nombre,descripcion;
    int id,precio;
    public Producto(){
    }
    
    /*Decidi crear los productos como productos quemados, para ahorrar tiempo al que corre el programa(profe), si fuera
    un programa de verdad, hubiera hecho la creacion de tales productos parte del sistema*/
    public void crearProductos(){
            Producto a = new Producto();
            Producto b = new Producto();
            Producto c = new Producto();
            Producto d = new Producto();
            Producto e = new Producto();
            Producto f = new Producto();
            Producto g = new Producto();
            Producto h = new Producto();
            Producto i = new Producto();
            Producto j = new Producto();
            a.setId(1);
            a.setNombre("Leche");
            a.setPrecio(1000);
            a.setDescripcion("leche de vaca descremada");
            b.setId(2);
            b.setNombre("Huevos");
            b.setPrecio(2000);
            b.setDescripcion("huevos de gallina criolla");
            c.setId(3);
            c.setNombre("Cereal");
            c.setPrecio(2500);
            c.setDescripcion("cereal de trigo fino");
            d.setId(4);
            d.setNombre("Arroz");
            d.setPrecio(3000);
            d.setDescripcion("arroz grano 90% puro");
            e.setId(5);
            e.setNombre("Carne molida");
            e.setPrecio(4500);
            e.setDescripcion("carne molida 95% res 5% grasa");
            f.setId(6);
            f.setNombre("Pan");
            f.setPrecio(2200);
            f.setDescripcion("Pan integral");
            g.setId(7);
            g.setNombre("Aceite de oliva");
            g.setPrecio(3000);
            g.setDescripcion("Aceite de oliva extra virgen 500ml");
            h.setId(8);
            h.setNombre("Frijoles");
            h.setPrecio(2500);
            h.setDescripcion("frijoles negros");
            i.setId(9);
            i.setNombre("Mantequilla");
            i.setPrecio(1500);
            i.setDescripcion("Mantequilla light");
            j.setId(10);
            j.setNombre("Cafe");
            j.setPrecio(2000);
            j.setDescripcion("Cafe costarricense puro");
            listP.add(a);
            listP.add(b);
            listP.add(c);
            listP.add(d);
            listP.add(e);
            listP.add(f);
            listP.add(g);
            listP.add(h);
            listP.add(i);
            listP.add(j);
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getPrecio() {
        return precio;
    }

    public List<Producto> getListP() {
        return listP;
    }  
}

