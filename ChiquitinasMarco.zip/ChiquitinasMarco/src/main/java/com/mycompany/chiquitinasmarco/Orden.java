package com.mycompany.chiquitinasmarco;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Orden{   
    List<Cliente> listC = new ArrayList<>();
    List<Item> listI,listIt = new ArrayList<>();
    List<Orden> listO = new ArrayList<>();
    ChiquitinasMarco ch= new ChiquitinasMarco();
    Scanner sc = new Scanner(System.in);
    int numeroOrden=1, idClienteCorrespondiente;
    String nombreC,dirC,corC,fechaC;

    public Orden(int idCLiente) {
        this.idClienteCorrespondiente=idCLiente;
    }
    public Orden crearOrden(){
        int item=0;
        this.listC=ch.getListC();
        Orden o = new Orden(idClienteCorrespondiente);
        o.setNumeroOrden(numeroOrden);
        o.setNombreC(listC.get(0).getNombre());
        o.setDirC(listC.get(0).getDireccion());
        o.setCorC(listC.get(0).getCorreo());
        numeroOrden++;
        System.out.println("Digite la fecha");
        o.setFechaC(sc.next());
        listO.add(o);
        System.out.println("Digite 1 si desea asignar un item a la orden, de lo contrario digite 2");
        item=sc.nextInt();
        do{
            for(int z=1;z<2;){
                Item i = new Item();
                int consecutivo,cantidad;
                i.crearItem();
                this.listI=i.getListI();
                System.out.println("La lista de items a elegir es ");
                i.leerItem();
                System.out.println("Digite el consecutivo del item a agregar a la orden");
                consecutivo=sc.nextInt();
                for(int x=0; x<listI.size();x++){
                    if(consecutivo==listI.get(x).getConsecutivo()){
                        i.setConsecutivo(consecutivo);
                        i.setNombreP(listI.get(x).getNombreP());
                        i.setDescripcionP(listI.get(x).getDescripcionP());
                        i.setPrecioP(listI.get(x).getPrecioP());
                        i.setIdP(listI.get(x).getIdP());
                        System.out.println("Digite la cantidad el producto que desea llevar");
                        cantidad=sc.nextInt();
                        i.setCantidadProducto(cantidad);
                        listIt.add(i);
                    }
                }
                System.out.println("Digite 1 si desea agregar otro item, 2 si ya no desea agregar otro ");
                z=sc.nextInt();
                arreglo();
            }
        }while(item==2);
            System.out.println("Orden creada");
            leerOrden(idClienteCorrespondiente); 
            return o;
    } 
    public void arreglo(){
        ch.listIte.addAll(this.listIt);
    }
            
    public void leerOrden(int idCC){
        idCC=idClienteCorrespondiente;
        int suma=0;
        this.listC=ch.getListC();
        //El error es que la lista esta vacia
        System.out.println(listO.size());
        for(int z=0; z<listO.size();z++){
            System.out.println("entro en el for");
            if(idCC==listO.get(z).getIdClienteCorrespondiente()){
                System.out.println("Numero de orden "+listO.get(z).getNumeroOrden());
                System.out.println("Id del cliente correspondiente "+listO.get(z).getIdClienteCorrespondiente());
                System.out.println("Fecha de creacion de orden " +listO.get(z).getFechaC());
                System.out.println("Nombre cliente " +listC.get(z).getNombre());
                System.out.println("Direccion del cliente "+listO.get(z).getDirC());
                System.out.println("Correo del cliente " +listO.get(z).getCorC());
                System.out.println("Items de la orden");
                for(Item it:listIt){
                    suma=(suma+(it.getPrecioP()*(it.getCantidadProducto())));
                    System.out.println("Consecutivo "+it.getConsecutivo());
                    System.out.println("Id "+it.getIdP());
                    System.out.println("Nombre "+it.getNombreP());
                    System.out.println("Descripcion "+it.getDescripcionP());
                    System.out.println("Cantidad "+it.getCantidadProducto());
                    System.out.println("Precio "+it.getPrecioP());          
                } 
                System.out.println("Precio total orden "+suma);
            }
        }
    }

    public void setIdClienteCorrespondiente(int idClienteCorrespondiente) {
        this.idClienteCorrespondiente = idClienteCorrespondiente;
    }

    public int getIdClienteCorrespondiente() {
        return idClienteCorrespondiente;
    }
    public  List<Item> devolverLista(List<Item> list){
        list=listIt;
        return list;
    }

    public void setListO(List<Orden> listO) {
        this.listO = listO;
    }

    public void setNumeroOrden(int numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public void setFechaC(String fechaC) {
        this.fechaC = fechaC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public void setDirC(String dirC) {
        this.dirC = dirC;
    }

    public void setCorC(String corC) {
        this.corC = corC;
    }

    public List<Orden> getListO() {
        return listO;
    }

    public int getNumeroOrden() {
        return numeroOrden;
    }

    public String getFechaC() {
        return fechaC;
    }

    public String getNombreC() {
        return nombreC;
    }

    public String getDirC() {
        return dirC;
    }

    public String getCorC() {
        return corC;
    }

    public List<Item> getListIt() {
        return listIt;
    }

    public void setListIt(List<Item> listIt) {
        this.listIt = listIt;
    }
}
